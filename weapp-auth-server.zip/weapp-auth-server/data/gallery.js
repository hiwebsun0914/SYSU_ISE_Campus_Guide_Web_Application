// data/gallery.js
module.exports = {
  images: [
    "https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/map.jpg"
  ]
};
