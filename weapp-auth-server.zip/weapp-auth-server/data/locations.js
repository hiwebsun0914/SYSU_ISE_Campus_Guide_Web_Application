module.exports = {
  locations: [
    {
      id: 1,
      name: '何尔达屋',
      position: '南校园311号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_001_he_er_da_house.jpg',
      description: `<p><strong>何尔达屋（Holt Residence）</strong>，原称<strong>34号住宅</strong>，现位于<strong>中山大学东北区311号</strong>，现为中山大学学报编辑部。该建筑由岭南大学美籍教员<strong>何尔达（Alfred H. Holt）</strong>的父亲捐资<strong>1.6万余元</strong>兴建，于<strong>1921年（民国十年）</strong>落成。</p>
<p>何尔达在岭南大学任教期间，曾<strong>三年不受薪俸</strong>，体现了对中国教育事业的支持与奉献。</p>
<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1921年</strong>：建成为何尔达住宅。</li>
  <li><strong>1930年</strong>：何尔达任教期满离开后，住宅成为岭南大学化学系教授兼理工学院院长<strong>富伦（Henry S. Frank）</strong>的长期居所。</li>
</ul>
<p>📖 <strong>富伦（Henry S. Frank）</strong>，岭南大学<strong>化学系</strong>教授，曾任理工学院院长，是岭南大学理科教育的重要推动者之一。他在岭南大学期间积极推动实验教学与科研的发展，对化学学科的建设和人才培养具有重要贡献。</p>`
    },
    {
      id: 2,
      name: '高利士屋',
      position: '南校园313号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_002_gao_lishi_house.jpg',
      description: `<p><strong>高利士屋（Coles Lodge）</strong>，又译高礼士屋、高士屋，原<strong>37号住宅</strong>，现位于<strong>中山大学东北区313号</strong>。该建筑由美国医生<strong>艾克曼·高利士（Dr. J. Ackerman Coles）</strong>捐建，美国纽约<strong>斯道顿建筑师事务所（Stoughton & Stoughton Architects）</strong>设计，广州<strong>Purnell & Paget住宅建筑行</strong>修改后兴建，于<strong>1913年（民国二年）</strong>落成。</p>
<p><strong>建筑特色：</strong>高利士屋为三层建筑，另设地下室和阁楼，红砖立面，细部装饰典雅，具有典型的岭南大学早期校园建筑风格。</p>
<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1913年</strong>：建成为岭南学校校医兼副监督、后任副校长的<strong>林安德医生（Dr. Andrew H. Woods）</strong>住宅。</li>
  <li><strong>1931年前后</strong>：岭南大学校长、监督<strong>香雅各博士（Dr. James M. Henry）</strong>曾居于此。</li>
  <li>其后曾居住于此的学者还包括：<strong>李嘉人校长</strong>、人类学系<strong>梁钊韬教授</strong>、行政管理学系<strong>夏书章教授</strong>。</li>
  <li><strong>2001年</strong>：学校斥资修复，并获<strong>香港杨雪姬女士</strong>资助。</li>
</ul>
<p>📖 <strong>林安德（Dr. Andrew H. Woods）</strong>，岭南学校校医兼副监督（1898–1907），后任副校长（1911–1916）。他是岭南医学教育与校园管理的重要奠基人，为岭南大学的早期发展作出贡献。</p>
<p>📖 <strong>香雅各（Dr. James M. Henry）</strong>，岭南大学监督、校长，1931年前后居于高利士屋。在任期间推动学校的制度化建设与学术发展，是岭南大学近代化的重要人物之一。</p>
<p>📖 <strong>李嘉人（1914.03.03–1979.12.22）</strong>，优秀的共产党员，曾任中共广东省委常委、副省长、中山大学第11任校长。他在任内强调本科教育与科研并重，贯彻“双百”方针，关心学生成长，推动教育事业发展。</p>
<p>📖 <strong>梁钊[zhāo]韬（1916–1987）</strong>，人类学家，字勉之，广东顺德人。曾长期居于高利士屋二楼。1981年，他积极奔走呼吁，促使教育部批准中山大学恢复停办30年的人类学系，被誉为中国人类学事业的重要奠基人。</p>
<p>📖 <strong>夏书章（1919.01.20–2024.07.24）</strong>，行政学家，江苏高邮人，中山大学行政管理学系教授，有“中国MPA之父”之称，是中国当代行政学的主要奠基人之一。在高利士屋期间，他以严谨刻苦的学风专心治学，潜心推动中国行政学教育与研究。</p>`
    },
    {
      id: 3,
      name: '宾省校屋',
      position: '南校园317号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_003_pennsylvania_school_house.jpg',
      description: `<p><strong>宾省校屋（Penn State Lodge）</strong>，又称<strong>宾省大学屋</strong>，原<strong>45号住宅</strong>，现位于<strong>中山大学东北区317号</strong>。该建筑由岭南大学农学院院长<strong>高鲁甫（George Weidman Groff）</strong>的母校——美国<strong>宾夕法尼亚州立大学</strong>的同学及学生捐资兴建，于<strong>1920年</strong>落成。</p>
<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1920年</strong>：宾省校屋建成，作为高鲁甫的住宅。</li>
  <li><strong>1908年</strong>：高鲁甫受母校派遣来华，后任岭南大学农学院院长，对岭南农科发展与校园园林规划作出重要贡献。</li>
  <li><strong>1952–1969年</strong>：著名教育家<strong>许崇清</strong>在此居住，其晚年论著《人的全面发展的教育任务》在此完成。</li>
</ul>
<p>📖 <strong>高鲁甫（George Weidman Groff，1884–?）</strong>，美国园艺学家、农学教育家，1907年毕业于宾夕法尼亚州立大学园艺系，1908年受派来华，后任岭南大学<strong>农学院</strong>院长。在校34年间，他主持校园园林规划，引入木瓜、奶牛等多种作物与畜种，被誉为“岭南农科之父”。他撰写的《岭南荔枝》获农林部甲等奖，1921年在纽约出版的《龙眼与荔枝》一书广为流传。夏威夷政府为感谢其贡献，将优良品种命名为<strong>“高鲁甫荔枝”</strong>。他还创办植物标本室，使岭南大学成为南方植物标本的重要收藏地。</p>
<p>📖 <strong>许崇清（1888–1969）</strong>，字志澄，广州人，中国教育家、哲学家。早年加入同盟会，参与辛亥革命。曾<strong>三度担任中山大学校长</strong>，共计二十年，被视为南中国文化旗手。他倡导工人识字教育，推动师范与职业教育发展，在教育理论上著有《杜威社会改造思想批判》《人类底实践与教育的由来》《人的全面发展的教育任务》等。其教育理念强调教育与国家社会紧密结合。1988年，教育界称其为“新教育学和新中国高等教育的奠基人之一”。</p>`
    },
    {
      id: 4,
      name: '端木正教授像',
      position: '南校园317栋东南侧',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_004_prof_duanmu_zheng_statue.jpg',
      description: `<p><strong>端木正教授像</strong>，位于中山大学康乐园图书馆东门旁。这座半身铜像的铭文为：“法学家  历史学家  端木正教授（1920–2006）”，为纪念这位学识渊博的教育家与法学大家而设。</p>
<p><strong>人物简介：</strong></p>
<ul>
  <li><strong>端木正（1920–2006）</strong>，安徽安庆人，回族，字昭定，号翼天。1942年毕业于武汉大学政治系，后考入清华大学国际法研究所深造，1948年前往法国巴黎大学获法学博士学位，1951年回国执教于岭南大学与中山大学。</li>
  <li>他曾于1980年推动<strong>中山大学法律学系复办</strong>，任首任系主任，并主持学科建设；历任最高人民法院副院长、海牙国际仲裁法院仲裁员，积极参与国家法治建设与国际交流。</li>
  <li>学术成就突出，师道尊严、春风化雨；其遗留藏书<strong>5000余册</strong>，由学校设立端木正教授藏书纪念室留存并向后学开放。</li>
</ul>`
    },
    {
      id: 5,
      name: '韦耶孝实屋',
      position: '南校园318号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_005_wei_yexiaoshi_house.jpg',
      description: `<p><strong>韦耶孝实屋（Weyerhaeuser Lodge）</strong>，又译<strong>卫厚实屋、委夏士屋、威尔豪士屋</strong>，原<strong>46号住宅</strong>，现位于<strong>中山大学东北区318号</strong>。该建筑由美国<strong>韦耶孝实夫人（Mrs. Frederick Weyerhaeuser）</strong>捐建，于<strong>1916年</strong>落成。</p>
<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1916年</strong>：建成后，作为岭南大学文理学院院长<strong>梁敬敦（Clinton Laird）</strong>的住宅。</li>
  <li>此后长期用作教师住宅。中文系<strong>王起（王季思）教授</strong>、中山大学第11校长<strong>李嘉人</strong>等均曾在此居住。</li>
  <li><strong>2004年8月</strong>：进行全面修缮，更换屋顶，原有的老虎窗被拆除。</li>
</ul>
<p>📖 <strong>梁敬敦（Clinton Laird，?-1942）</strong>，岭南大学文理学院院长，1905年来华任教，致力于岭南教育事业。1941年返美休养后，<strong>不顾年迈重返战时粤北</strong>，在坪石继续教学。后因病赴港手术，期间遭日军拘捕入集中营，6个月后通过俘虏交换返美，但旧病复发，于<strong>1942年11月</strong>在美国病逝。</p>
<p>📖 <strong>王起（王季思，1911–1983）</strong>，中国著名戏剧家、翻译家，曾任中山大学中文系教授，长期从事<strong>莎士比亚戏剧</strong>与<strong>中国戏剧史</strong>研究，是中国现代戏剧教育的重要奠基者之一。</p>
<p>📖 <strong>李嘉人（1914–1979）</strong>，优秀的共产党员，曾任广东省副省长、<strong>中山大学第11任校长</strong>。他在任期间强调本科教育与科研并重，贯彻“双百”方针，关心学生成长，推动教育事业发展。</p>
`
    },
    {
      id: 6,
      name: '伦敦会屋',
      position: '南校园316号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_006_london_missionary_society_house.jpg',
      description: `<p><strong>伦敦会屋（London Mission Lodge）</strong>，又称<strong>L.M.S 屋</strong>，原<strong>44号住宅</strong>，现位于<strong>中山大学东北区316号</strong>。该建筑由<strong>英国伦敦布道会（London Missionary Society）</strong>捐建，以供派来岭南学校任职的教员居住，于<strong>1916年</strong>落成。</p>
<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1916年</strong>：建成为岭南学校副监督、宗教主任<strong>白士德（Alexander Baxter）</strong>的住宅。</li>
  <li>孙中山先生发表“立志做大事”演讲时，正是由<strong>白士德</strong>以岭南大学代校长身份迎接并陪同。</li>
  <li>此后长期作为教师住宅使用，中山大学原校长<strong>黄焕秋</strong>亦曾在此居住。</li>
</ul>
<p>📖 <strong>白士德（Alexander Baxter）</strong>，<strong>英国伦敦布道会</strong>派驻岭南学校的副监督与宗教主任，曾代理岭南大学校长职务，是岭南大学早期重要的外籍教育人物之一。</p>
<p>📖 <strong>黄焕秋（1916–2010）</strong>，广东惠州人，中国著名教育家。1937年毕业于<strong>中山大学教育系</strong>，后长期任职于中山大学，历任<strong>教务处长、副校长、校长、党委书记</strong>等职。20世纪70年代末，他主持<strong>中山大学院系复办</strong>，顶住压力重建<strong>法律、经济、人类学、社会学、计算机</strong>等专业，使中山大学逐步发展为综合性大学。在恢复文科与引进人才方面勇于突破禁区，被誉为中大“文科复兴”的奠基人。</p>`
    },
    {
      id: 7,
      name: '美臣屋一号',
      position: '南校园319号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_007_meichen_house_no1.jpg',
      description: `<p><strong>美臣屋一号（Mason Lodge No.1）</strong>，原<strong>47号住宅</strong>，现位于<strong>中山大学东北区319号</strong>。该建筑由<strong>美国美臣先生（George Grant Mason）</strong>捐建的两栋教师住宅之一，于<strong>1919年</strong>落成。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>20世纪30年代：岭南大学<strong>彭美赍</strong>与文理学院教授兼数学系主任<strong>麦丹路</strong>先后在此居住。</li>
  <li>1949–1964年：岭南大学校长、中山大学副校长<strong>陈序经教授</strong>居住于此，并完成《陈序经东南亚古史研究合集》。</li>
  <li>1970年前后：中山大学数学系主任<strong>许淞庆教授</strong>与<strong>梁之舜教授</strong>居住于二楼。</li>
</ul>

<p><strong>建筑特色：</strong>两层结构，设有地下室与阁楼。原东西各有烟囱，西侧烟囱已拆除。原首层入门朝北，后改为朝南并加盖门亭；二层入口位于西北角。</p>

<p>📖 <strong>陈序经（1903–1967）</strong>，字怀民，广东文昌人，中国现代著名的<strong>历史学家、社会学家、民族学家与教育家</strong>。曾任岭南大学校长、中山大学副校长。他在1933年的《中国文化的出路》演说中提出<strong>“全盘西化”</strong>主张，引发全国文化论战。在学术研究方面，他通过田野调查，对<strong>疍民、黎族、苗族</strong>等群体展开研究，并在东南亚古史研究中取得重要成就。</p>`
    },
    {
      id: 8,
      name: '白德理屋',
      position: '南校园324号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_008_bai_deli_house.jpg',
      description: `<p><strong>白德理屋（Bradley House）</strong>，又称<strong>白德理纪念屋</strong>，原<strong>53号住宅</strong>，现位于<strong>中山大学东北区324号</strong>。该建筑由<strong>白德理先生</strong>为纪念其妻<strong>Lois Gates Bradley</strong>捐建，建成年份约在<strong>1927年前后</strong>。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>最初作为<strong>单身女教工宿舍</strong>使用。</li>
  <li>此后长期作为教师住宅，岭南大学<strong>何马利</strong>、<strong>韩德信</strong>、<strong>卫民</strong>、<strong>史托利</strong>等教授先后居住于此。</li>
</ul>

<p>📖 <strong>何马利（Mary Ho）</strong>，岭南大学教师，致力于外语教育与跨文化交流，是早期岭南校园国际化师资队伍的重要代表之一。</p>

<p>📖 <strong>韩德信（Han Dexin）</strong>，岭南大学<strong>理学院</strong>教授，长期专注于数理学科教学与研究，对岭南大学理科的发展起到推动作用。</p>

<p>📖 <strong>卫民（Wei Min）</strong>，岭南大学教师，关心学生学业与成长，积极参与校园公共事务，体现了岭南教育的人文关怀。</p>

<p>📖 <strong>史托利（Storrie）</strong>，岭南大学外籍教师，活跃于人文学科领域，在课堂教学与学术研究上均有建树，推动了岭南大学学术交流与中西文化沟通。</p>`
    },
    {
      id: 9,
      name: '屈林宾屋',
      position: '南校园329号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_009_qu_linbin_house.jpg',
      description: `<p><strong>屈林宾屋（William Penn Lodge）</strong>，又译<strong>威林滨屋、威林宾屋</strong>，原<strong>54号住宅</strong>，现位于<strong>中山大学东北区329号</strong>。该建筑由岭南学校医学家<strong>嘉惠林医生（Dr. William W. Cadbury）</strong>的同乡好友、来自美国宾夕法尼亚州的<strong>威林宾先生（William Penn）</strong>捐建，于<strong>1914年</strong>落成。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>最初作为<strong>嘉惠林医生住宅</strong>使用。</li>
  <li>其后长期作为岭南大学教师宿舍。</li>
</ul>

<p>📖 <strong>嘉惠林（Dr. William W. Cadbury，1877–1959）</strong>，美国著名医学家和传教士，宾夕法尼亚人。1909年来华，在岭南大学医学院任教，后任<strong>岭南大学医学院院长</strong>，积极推动岭南地区的医学教育和公共卫生事业。他不仅在医学教学与临床工作中贡献突出，还长期服务于中国红十字会，推动公共卫生救护体系建设。在其倡导下，岭南大学医学院逐渐成长为南中国重要的医学教育中心。</p>`
    },
    {
      id: 10,
      name: '惠师礼屋',
      position: '南校园332号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_010_hui_shili_house.jpg',
      description: `<p><strong>惠师礼屋（Wesley House）</strong>，又译<strong>卫斯理会屋</strong>，又称<strong>李富士屋</strong>，原<strong>49号住宅</strong>，现位于<strong>中山大学东北区332号</strong>。该建筑由<strong>英格兰惠师礼循道会（Wesleyan Methodist Missionary Society of England）</strong>捐建，于<strong>1924–1925年</strong>间落成。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>最初作为惠师礼循道会派驻岭南大学的<strong>李富士先生（Ronald D. Rees）</strong>住宅。</li>
  <li>其后长期作为教师住宅。</li>
  <li>惠师礼屋为两层建筑，设有地下室与阁楼，现西侧加建一间简易平房。</li>
</ul>

<p>📖 <strong>李富士（Ronald D. Rees）</strong>，英格兰惠师礼循道会派驻岭南大学的教育人士，致力于岭南的教育与文化交流。他不仅在教学上贡献突出，还推动中西教育理念的融合，是岭南校园早期的重要外籍教师之一。</p>

<p>🌳 <strong>学术交流：</strong>如今，惠师礼屋作为<strong>中山大学中国区域协调发展与乡村建设研究院</strong>的所在地，既保留了岭南校园的历史印记，也继续发挥着学术与文化交流的功能。例如2023年12月15日，“RCEP背景下中国–东盟高质量发展学术研讨会暨《2023年越南区域国别发展研究报告》研讨会”就在此举办。</p>
`
    },
    {
      id: 11,
      name: '马岗堂',
      position: '南校园338号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_011_magang_hall.jpg',
      description: `<p><strong>马岗堂（Lingnan Chapel）</strong>，又称<strong>马岗顶礼拜堂、岭南礼拜堂、新教堂</strong>，原属岭南大学校园编号<strong>85号建筑</strong>，现位于<strong>中山大学东北区338号</strong>。该建筑由岭南社团及海外友人捐建，于<strong>1936年</strong>落成。</p>

<p><strong>使用功能：</strong></p>
<ul>
  <li>最初为小型基督教礼拜堂。</li>
  <li>大学晨会亦在此举行。</li>
  <li>现在为广东省人民政协理论研究会中山大学研究基地，中山大学民主党派办公室、统战团体办公室。</li>
</ul>
`
    },
    {
      id: 12,
      name: '图书馆',
      position: '南校园335号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_012_library.jpg',
      description: `<p><strong>中山大学图书馆</strong>，始建于<strong>1924年</strong>，历经近百年发展，现已成为覆盖文、理、医、工、农、艺术等多学科的综合性文献信息服务中心。</p> 
      <p><strong>馆藏资源：</strong></p> 
      <ul> 
        <li>实体文献逾<strong>1000万册/件</strong></li> 
        <li>古籍36万余册，民国文献14万余册</li> 
        <li>特色文献40余万件</li> 
        <li>电子图书320万余册，电子期刊14万余种</li> 
        <li>各类数据库1000余个</li> 
    </ul> 
    <p><strong>历史与传承：</strong></p> 
    <ul> 
        <li>抗日战争期间损失图书20余万册，幸存约4.5万册</li> 
        <li>战后迅速恢复并扩展馆藏</li> 
        <li>如今已成为校园文化与学术精神的重要象征</li> 
    </ul> 
    <p><strong>馆务筹建：</strong></p> 
    <ul> 
        <li><strong>1924年</strong>建校初期，校长<strong>邹鲁</strong>致函全国多家高校与公共图书馆，请寄送<strong>书目、规程、周年报告及各类印刷品</strong>各一份，以资借鉴，推动本校图书馆<strong>“扩张整理”</strong>。</li> 
        <li>去函对象含：京师图书馆及分馆、国立北京大学、清华学校，直隶/山东/山西/河南/江苏（第一）/浙江/福建/云南/奉天等省立图书馆，南通县立与无锡图书馆，云南省教育会图书馆，<em>商务印书馆涵芬楼</em>、<em>文华大学公书林</em>，以及中州大学、西北大学、东北大学等。</li> 
        <li>文件信息：题为“<em>致各图书馆函</em>”，落款“<strong>校长邹鲁</strong>”，日期“<strong>十月十七日</strong>”。</li> 
        <li>来源：国民党党史会藏史料，转录自《<em>邹鲁先生文集</em>》，中国国民党中央委员会党史委员会1984年编印，第391页。</li> 
    </ul>
`
    },
    {
      id: 13,
      name: '黄焕秋校长像',
      position: '南校园图书馆五楼南区',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_013_zou_lu_president_statue.jpg',
      description: `<p><strong>黄焕秋校长像</strong>，位于<strong>中山大学广州校区南校园图书馆五楼南区</strong>，铜像目光如炬、面容温和，静静伫立于书香之间。这位被师生亲切唤作“焕秋同志”的老校长，被誉为<strong>“革命的教育家、教育的革命家”</strong>，其雕像与图书馆的知识氛围相得益彰，见证了他为中大发展倾注的毕生心血。</p>

<p>黄焕秋于<strong>1933年</strong>考入中山大学文学院教育系，大学期间便通过班刊《解者》宣传抗日与教育改革，显露出革命与教育并重的初心。抗战时期，他参与编辑《教育新时代》等杂志，以新观点研究教育理论，被誉为<strong>“浓黑中的几画灯火”</strong>。新中国成立后，他历任中山大学多项要职，以远见与魄力推动学校革新。面对院系调整，他力排<strong>“重理工、轻人文”</strong>的偏见，复办或增设法律、经济、人类学、管理学等学科——如今稳居全国前列的管理学院，正得益于他当年延揽专家、争取华侨资金的远见卓识。</p>

<p>他打破<strong>“以出身论英雄”</strong>的桎梏，破格录用有才华却因历史问题被冷落的人才，例如将珠江电影制片厂的日语人才引入中大，使之成长为日语系骨干。改革开放后，他更是引领中大走向世界：<strong>1979年</strong>率团访问美国，成为改革开放后内地首个出访的高校学术代表团，随后推动与日本、法国、加拿大等国名校建立合作关系；他还主导成立<strong>英语培训中心</strong>与<strong>汉语培训中心</strong>（后发展为国际汉语学院），开创了中大对外交流的先河。</p>

<p>在学生科研方面，他重视计划的切实与设备的活用，强调时间保障与思想教育并重，鼓励自由讨论。他待人随和，与师生平等相处，办公室、家中、路上常有人向他倾诉，这份亲和力让“焕秋同志”的称呼深入人心。<strong>2012年</strong>，铜像与《黄焕秋文集》一同亮相，纪念他自求学至工作与中大相守的半个多世纪——他让开明自由的学术精神薪火相传，为学校走向世界奠定了根基，而铜像那温暖而坚定的目光，至今仍激励着中大人传承革新与包容的校风。</p>
`
    },
    {
      id: 14,
      name: '格兰堂',
      position: '南校园333号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_014_gelan_hall.jpg',
      description: `<p><strong>格兰堂（Grant Hall）</strong>，因为一口大钟掌握园内上下课时间，所以又称<strong>大钟楼</strong>。原<strong>63号建筑</strong>，现位于<strong>中山大学东北区333号</strong>,现为校史馆。该建筑由<strong>美国纽约斯道顿建筑师事务所（Stoughton & Stoughton Architects）</strong>设计，<strong>1915年</strong>动工，<strong>1916年6月</strong>落成，20世纪60年代初曾加建一层。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>建筑由<strong>约翰·肯尼迪夫人（Mrs. John S. Kennedy）</strong>捐建，其姐<strong>苏夫勒夫人</strong>资助购置堂内家具，美国<strong>高利士先生（J. Ackerman Coles）</strong>捐赠楼顶大钟。</li>
  <li>堂名依捐赠人意愿，以纪念<strong>格兰先生（William Henry Grant）</strong>，他曾任岭南学堂前身格致书院纽约董事局书记兼司库，长期义务为校宣传与筹款。</li>
  <li>格兰堂原为学校事务所，二楼东侧曾设图书馆。</li>
  <li>中山大学迁入康乐园后，格兰堂曾用作学校行政楼。</li>
</ul>

<p>📖 <strong>建筑特色：</strong>格兰堂原为两层，设有地下室，坐北朝南，外观气势恢宏。正立面由<strong>五个大拱券</strong>构成，中部圆窗原刻<strong>“GH”</strong>缩写，近年重修恢复。门廊两侧嵌有<strong>中英文石板</strong>，刻录捐赠人姓名，是岭南校园最具象征性的历史建筑之一。</p>
`
    },
    {
      id: 15,
      name: '廖承志像',
      position: '南校园333栋东侧',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_015_liao_chengzhi_statue.jpg',
      description: `<p><strong>廖承志像</strong>，位于<strong>中山大学南校园图书馆南侧绿地</strong>。雕像为半身铜像，人物手托腮帮，面带微笑，神情和蔼，仿佛随时倾听后辈。该像由<strong>邓颖超</strong>题词，于<strong>1985年9月</strong>立成，成为校园师生瞻仰与缅怀的文化标志。</p>

<p><strong>人物简介：</strong></p>
<ul>
  <li><strong>廖承志（1908–1983）</strong>，中国无产阶级革命家、政治家，国民革命先驱廖仲恺与何香凝之子。</li>
  <li>早年投身学生运动，后长期从事华侨事务，曾任<strong>华侨事务委员会主任、华侨大学校长</strong>等职。</li>
  <li>他为国家与侨界联系、侨务政策建设及中外交流作出重大贡献。</li>
</ul>

<p><strong>校园记忆：</strong>雕像落成后，校园在周围补种<strong>杜鹃</strong>，春季盛开之时，铜像与花木相映成趣，成为中大人文景观之一。</p>
`
    },
    {
      id: 16,
      name: '马丁堂',
      position: '南校园334号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_016_martin_hall.jpg',
      description: `<p><strong>马丁堂（Martin Hall）</strong>，原<strong>61号建筑</strong>，现位于<strong>中山大学东北区334号</strong>。该堂由<strong>美国纽约斯道顿建筑师事务所（Stoughton & Stoughton Architects）</strong>设计，<strong>1905年</strong>开工，<strong>1906年</strong>落成。建设资金由美国纽约董事局通过出售证券筹得2.5万美元，最大捐资者为<strong>亨利·马丁先生（Henry Martin）</strong>，故以其名命堂。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>马丁堂初称“东堂”，与西院史达理堂相对。</li>
  <li>为康乐园内第一栋永久性建筑，也是<strong>中国第一栋钢筋混凝土混合结构建筑</strong>，并首次采用硬质红砖和混凝土地面。</li>
  <li>建筑规模：长50.68米、宽16.14米、高15.8米，总面积2516.48平方米，共三层，另有地下室与阁楼。</li>
  <li>南立面正中央设主入口，两侧对称次入口，门楣刻有<strong>“AD1905”</strong>；南门入口曾嵌<strong>“MARTIN HALL”</strong>堂匾，现换为<strong>费孝通先生题写的“中山大学人类学系”</strong>。</li>
  <li><strong>1912年5月7日</strong>：孙中山先生莅临岭南学堂，在此发表<strong>《非学问无以建设》</strong>的演讲，并与师生合影。</li>
  <li>长期作为岭南学堂的教学、办公和图书馆馆舍使用。</li>
  <li><strong>1996年</strong>：被建设部、国家文物局和中国建筑学会评为<strong>中国优秀近代建筑</strong>。</li>
</ul>

<p><strong>建筑意义：</strong>马丁堂以红砖绿瓦、中式屋顶与西式墙身结合的设计开创了岭南大学校园建筑的基调，成为康乐园建筑群的奠基之作。它既承载了岭南学堂的早期教学历史，又见证了中西建筑技艺在岭南校园的融合。</p>

<p><strong>建筑趣闻：</strong>堂前石狮为岭南大学首任华人校长<strong>钟荣光先生</strong>从学校附近被拆除的庙宇内寻得，造型独特，是典型的“南狮”，后来成为校园吉祥物“<strong>中大狮</strong>”的灵感起源。</p>`
    },
    {
      id: 17,
      name: '附属小学建筑群',
      position: '南校园339-346号，341为陈嘉庚堂',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_017_affiliated_primary_school_complex.jpg',
      description: `<p><strong>附属小学建筑群</strong>，现位于<strong>中山大学东北区339-346号</strong>，由8栋楼和1座方亭构成。其中东北区339-345号共7栋楼呈南北走向阶梯斜列；东北区346号与方亭则位于斜列以西，落成年代稍晚。建筑群建设费用主要依靠华人募捐，先后落成于<strong>1915–1930年</strong>间。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1908年</strong>：岭南大学附属小学前身为<strong>蒙养学塾</strong>，由岭南大学基督教青年会同学司徒卫创办。</li>
  <li><strong>1911年</strong>：小学正式成立，初设于附近乡村。</li>
  <li><strong>1914年</strong>：小学转交岭南大学接办，迁入康乐园，新建校舍以满足教学与师生生活需求。</li>
  <li>除<strong>341号陈嘉庚堂</strong>和<strong>346号</strong>外，其余校舍均坐北朝南，建筑风格基本相似，每栋楼均为一个年级的学习与住宿场所。</li>
</ul>

<p><strong>主要建筑：</strong></p>
<ul>
  <li><strong>小学第一栋（339号）</strong>：由王广昌、李秬香、梁星垣捐建，1915年落成。</li>
  <li><strong>小学第二栋（340号）</strong>：由马应彪捐建一层，莫藻泉和阮达臣合捐一层，1915年落成。</li>
  <li><strong>陈嘉庚堂（341号）</strong>：附小礼堂，1919年落成。为纪念华侨领袖<strong>陈嘉庚</strong>率先认捐而命名。</li>
  <li><strong>小学第三栋（342号）</strong>：丘燮亭、刘振芳、黄焕南、黄在扬捐建，1916年落成。</li>
  <li><strong>小学第四栋（343号）</strong>：与第三栋同为丘燮亭等人捐建，1916年落成。</li>
  <li><strong>小学第五栋（344号）</strong>：由张朱澜芝夫人捐建，1919年落成。</li>
  <li><strong>小学第六栋（345号）</strong>：曹灿三、谭亦张捐建，1930年落成。</li>
  <li><strong>小学第七栋（346号）</strong>：1948年11月建成，为附小课室与办公室。</li>
  <li><strong>方亭（Kiosk）</strong>：原52号建筑，建成时间早于1932年。</li>
</ul>

<p>📖 <strong>陈嘉庚（1874–1961）</strong>，字甲庚，福建同安人，著名爱国华侨领袖、实业家与教育家。他在教育上倾力投入，1913年创办集美学校，1921年创办厦门大学，并推动集美学村建设。他积极支持中国革命与抗日救亡运动，组织华侨支援祖国抗战。新中国成立后回国定居，担任政协全国委员会副主席等职务，被毛泽东誉为“华侨旗帜，民族光辉”。习近平总书记亦强调过“陈嘉庚精神”的重要意义。</p>

<p><strong>1924年教科用书：</strong></p>
<ul>
  <li>新学制小学《国语读本》三册</li>
  <li>新学制小学《地理读本》三册</li>
  <li>新学制小学《历史读本》三册</li>
  <li>新时代小学《国文读本》四册</li>
  <li>新式《初等历史读本》二册</li>
  <li>新式《初等地理读本》二册</li>
  <li>初级中学《国语读本》三册</li>
  <li>高级中学《国语读本》三册</li>
  <li>中学《国语文读本》四册</li>
  <li>详注《现代文读本》二册</li>
  <li>《清代文评注读本》二册</li>
  <li>《历代文评注读本》四册</li>
</ul>

<p><strong>1924年儿童用书：</strong></p>
<ul>
  <li>《儿童识字百日通》二册</li>
  <li>《儿童作文初步》二册</li>
  <li>《儿童作文入门》二册</li>
  <li>《儿童智识读本》六册</li>
  <li>《儿童模范》一册</li>
  <li>《少年模范》（正集）四册，（续集）四册</li>
  <li>《国民模范》四册</li>
  <li>《言文对照二十四孝》一册</li>
  <li>《白话伊索寓言》一册</li>
  <li>《童话大观》正集九册，《童话大观》续集九册</li>
  <li>《绘图小学生》十二册</li>
  <li>《儿童游戏大观》一册</li>
</ul>

<p><em>合计：教科与儿童用书计二十四种，共八十九册。</em></p>
`
    },
    {
      id: 18,
      name: '南草坪餐厅',
      position: '南校园347号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_018_south_lawn_dining_hall.jpg',
      description: `<p><strong>南草坪餐厅</strong>，位于<strong>中山大学南校园南草坪区域</strong>，是校园内重要的学生食堂之一。餐厅整体设计简洁实用，服务于大规模的学生日常就餐需求。</p>

<p><strong>基本情况：</strong></p>
<ul>
  <li>餐位总数：<strong>616个</strong>。</li>
  <li>主要服务对象：南校园学生及教职工。</li>
  <li>地理位置：邻近南草坪，交通便利，与教学区和宿舍区均相距不远。</li>
</ul>

<p><strong>功能与意义：</strong></p>
<p>南草坪餐厅不仅是日常就餐的主要场所，也是学生社交、休憩与交流的空间。其开放式布局与草坪环境相映成趣，使其成为校园生活的重要组成部分。</p>
`
    },
    {
      id: 19,
      name: '第一教学楼',
      position: '南校园348号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_019_teaching_building_1.jpg',
      description: `<p><strong>第一教学楼</strong>，位于<strong>中山大学南校园348栋</strong>，是康乐园内规模较大的教学建筑之一。全楼共<strong>六层</strong>，以多媒体阶梯课室为主，是本科生上课的核心场所。有大小教师50多间，可容纳学生4000多人。从它六层的高窗远望康乐园，既能感受到岭南红楼的厚重历史，也能体会到当下青春的蓬勃气息。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>建成为南校园扩建时期的重要教学设施，旨在集中解决大规模课堂教学需求。</li>
  <li>全楼为教学用途，主要承担文理学科的大课与通识课程。</li>
  <li>长期以来，这里见证了南校园本科教学的发展，成为学子记忆中最常出入的学习场所。</li>
</ul>
`
    },
    {
      id: 20,
      name: '附属小学方亭',
      position: '南草坪餐厅后',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_020_affiliated_primary_school_pavilion.jpg',
      description: `<p><strong>方亭</strong>，位于<strong>中山大学东北区342号以西</strong>，是康乐园早期校园建筑群的重要组成部分之一。该亭建成时间早于<strong>民国二十一年（1932）</strong>，为岭南校园生活与交流空间提供了别样的文化氛围。</p>

<p><strong>建筑特色：</strong></p>
<ul>
  <li>建筑材料以<strong>红砖</strong>为主，延续岭南校园红楼群的一致风格。</li>
  <li>屋顶采用<strong>宝蓝色琉璃瓦</strong>，色泽鲜明，在绿荫环绕的校园中尤为醒目。</li>
  <li>结构形式为<strong>四角攒尖顶</strong>，造型简洁而典雅，既有东方传统建筑韵味，又与周围红楼建筑群相映成趣。</li>
</ul>`
    },
    {
      id: 21,
      name: '荣光堂',
      position: '南校园350号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_021_rongguang_hall.jpg',
      description: `<p><strong>荣光堂（Wing Kwong Hall）</strong>，原<strong>21号建筑</strong>，现位于<strong>中山大学东北区350号</strong>。该建筑由<strong>埃德蒙兹（Jas. R. Edmunds Jr.）</strong>与<strong>尤茨（Philip N. Youtz）</strong>于1921年设计，<strong>1924年</strong>落成，20世纪70年代加建一层。因当时学生人数不断增加，原有宿舍已不敷使用，岭南大学学生自发利用假期前往省港等地募款，历时两年，最终在莫干生、林植豪、陆蓬山、肖瀛洲、杨西严、林植生、简达才、刘季焯、蔡叻谱等校友的资助下建成。</p>

<p><strong>命名由来：</strong></p>
<ul>
  <li>为纪念岭南大学首任华人校长<strong>钟荣光博士</strong>对学校的贡献，命名为“荣光堂”。</li>
  <li>现堂匾“荣光堂”为岭南著名学者<strong>容庚先生</strong>所题。</li>
</ul>

<p><strong>钟荣光（1866—1942）</strong>，字惺可，广东香山县（今中山市）小榄人，是中国近代民主革命家、教育家，被尊称为“岭大之父”。</p>
<ul>
  <li>1896年加入孙中山先生领导的兴中会，投身革命。</li>
  <li>历任岭南学堂<strong>教务长、副监督（副校长）、监督（校长）大学，并于1927—1938年担任岭南大学<strong>校长</strong>。</li>
  <li>他在任期间扩充学科，增设农学院、工学院、商学院，使岭南大学成为南中国的重要综合性大学。</li>
  <li>曾在<strong>陈炯明叛变</strong>时勇敢保护<strong>宋庆龄</strong>并帮助其安全撤离。</li>
  <li>以超凡的筹款能力闻名，曾环游世界为岭南大学募集资金，奠定学校发展的财政基础。</li>
</ul>

<p><strong>历史沿革与功能：</strong></p>
<ul>
  <li>荣光堂建成后作为大学寄宿舍使用，与<strong>爪哇堂</strong>（大学第一寄宿舍）、<strong>陆祐堂</strong>（大学第三寄宿舍）并列为岭大主要学生宿舍。</li>
  <li>70年代加建一层后，使用功能有所调整，但仍是学生生活的重要空间。</li>
</ul>

<p><strong>趣闻轶事：</strong></p>
<ul>
  <li>荣光堂是岭大学生<strong>“自力更生”</strong>的象征——学生们假期走街串巷募捐，足迹遍及省港，最终促成此宿舍落成，被誉为<strong>“学生亲手筹建的红楼”</strong>。</li>
  <li>堂名“荣光”，不仅取自<strong>钟荣光校长</strong>之名，也寓意“光荣”，象征岭南精神的延续。</li>
</ul>
`
    },
    {
      id: 22,
      name: '中山大学南门',
      position: '-',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_022_sysu_south_gate.jpg',
      description: `<p><strong>中山大学南门</strong>，是广州南校园的标志性大门之一，也是最具辨识度的校门形象。南门面向广州市海珠区新港西路，正对康乐园的中轴线，承载了学校厚重的历史记忆与文化象征。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>南门所在位置原为岭南大学校园出入口之一，随着1920年代康乐园校园的建设而逐渐形成。</li>
  <li>1950年代以后，中山大学逐步扩建，南门成为学校对外主要门户。</li>
  <li>如今南门既是校史记忆的延续，也是现代校园交通与文化交流的重要节点。</li>
</ul>

<p><strong>建筑特色：</strong></p>
<ul>
  <li>南门以<strong>红砖立柱</strong>与<strong>灰色瓦顶</strong>为主，延续了岭南大学红楼群的风格。</li>
  <li>门额镌刻“<strong>中山大学</strong>”四字，字体端庄大气，是学校的标志性形象。</li>
  <li>整体造型简洁而庄重，与两侧的绿荫大道及康乐园红楼群形成呼应。</li>
</ul>`
    },
    {
      id: 23,
      name: '生命科学楼',
      position: '南校园408号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_023_life_sciences_building.jpg',
      description: `<p><strong>中山大学生命科学学院</strong>，前身可追溯至<strong>1924年建校伊始设立的生物学系</strong>，于<strong>1991年</strong>正式成立生命科学学院。学院位于<strong>广州校区南校园</strong>，是中国生命科学领域的重要教学与科研中心。</p>

<p><strong>科研与平台：</strong></p>
<ul>
  <li>水产动物疫病防控与健康养殖全国重点实验室</li>
  <li>中国-东盟海水养殖技术“一带一路”联合实验室</li>
  <li>国家生猪技术创新中心华南分中心</li>
  <li>基因功能与调控教育部重点实验室</li>
  <li>生物学国家实验教学示范中心</li>
</ul>

<p><strong>教学与人才培养：</strong></p>
<ul>
  <li>本科专业：生物科学、生物技术、生态学、生物信息学（共4个）。</li>
  <li>博士点17个，硕士点21个。</li>
  <li>生物科学入选首批“强基计划”，同时是国家“拔尖计划”1.0与2.0专业。</li>
  <li>本科专业全部入选“双万计划”国家一流本科专业建设点。</li>
</ul>

<p><strong>师资与队伍（共344人）：</strong></p>
<ul>
  <li>教授 / 研究员 73人</li>
  <li>副教授 71人</li>
  <li>专职科研人员（含博士后）87人</li>
  <li>国家级高层次杰出人才13人，国家优秀人才21人</li>
  <li>全国农业产业体系<strong>首席科学家</strong>2人</li>
</ul>

<p><strong>文化与使命：</strong></p>
<p>学院坚持“面向国家战略需求、面向区域经济社会发展、面向学术前沿、面向人民生命健康”的办学理念，聚焦生命健康与种业安全两大领域，打造科研大平台，开展生命组学、免疫与衰老、微生物智造与生物防治、养殖动物健康、植物逆境生物学、生态与进化六大方向的研究。学院在培养原始创新能力、国际视野与服务国家需求的领军人才方面已形成鲜明特色。</p>`
    },
    {
      id: 24,
      name: '蚕丝学院制种室',
      position: '南校园410号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_024_sericulture_institute_breeding_room.jpg',
      description: `<p><strong>蚕丝学院制种室</strong>，又称<strong>育蚕制种场、飞利达育蚕室、蚕科宿舍、蚕丝传习所</strong>，原<strong>40号建筑</strong>，现位于<strong>中山大学西南区410号</strong>。该楼由纽约丝绸进口商<strong>马科斯·飞利达（Marcus Fieldler，又译富利达）</strong>捐建，<strong>1921年</strong>落成。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1916年</strong>：岭南大学查理·考活（Charles W. Howard）教授设立<strong>经济昆虫实验室</strong>，奠定蚕丝学研究基础。</li>
  <li><strong>1921年</strong>：制种室建成，成为<strong>岭南大学蚕丝学院建筑群</strong>的一部分。</li>
  <li><strong>1927年</strong>：岭南大学蚕丝学院成立，得到美国丝业协会与广东省政府扶持，先后发展为蚕丝学系、岭南丝业研究所及广东省建设厅蚕丝改良局，1921年并入农学院。</li>
  <li><strong>制种室</strong>与同期的<strong>育种室、缫丝厂、无病蚕室</strong>，共同构成岭南大学蚕丝学院的<strong>四大专用建筑</strong>。</li>
  <li><strong>20世纪80—90年代</strong>：其余三栋建筑相继拆除，仅余制种室保存至今。</li>
</ul>

<p><strong>1924年桑蚕系科目：</strong></p>
<ul>
  <li><strong>蚕桑泛论：</strong>授课<strong>三</strong>，实习<strong>二</strong></li>
  <li><strong>蚕体解剖学：</strong>授课<strong>二</strong>，实习<strong>三</strong></li>
  <li><strong>蚕体生理学：</strong>授课<strong>二</strong>，实习<strong>—</strong></li>
  <li><strong>蚕体病理学：</strong>授课<strong>二</strong>，实习<strong>二</strong></li>
  <li><strong>蚕病消毒法：</strong>授课<strong>三</strong>，实习<strong>—</strong></li>
  <li><strong>养蚕学：</strong>授课<strong>二</strong>，实习<strong>—</strong></li>
  <li><strong>养蚕实习：</strong>授课<strong>无定时</strong>，实习<strong>—</strong></li>
  <li><strong>制种学：</strong>授课<strong>二</strong>，实习<strong>—</strong></li>
  <li><strong>栽桑学：</strong>授课<strong>二</strong>，实习<strong>—</strong></li>
  <li><strong>桑树害病：</strong>授课<strong>二</strong>，实习<strong>二</strong></li>
  <li><strong>桑种改良学：</strong>授课<strong>二</strong>，实习<strong>—</strong></li>
  <li><strong>制丝学：</strong>授课<strong>三</strong>，实习<strong>三</strong></li>
  <li><strong>论文：</strong>授课<strong>—</strong>，实习<strong>—</strong></li>
</ul>
<p><small>注：“—”为原表未注明；“无定时”为原表原文。</small></p>
`
    },
    {
      id: 25,
      name: '生物楼',
      position: '南校园415号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_025_biology_building.jpg',
      description: `<p><strong>生物楼</strong>，位于<strong>中山大学南校园415栋</strong>，是中大生物学科在康乐园发展的重要历史见证。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1950年代</strong>：根据全国院系大调整，岭南大学生物学系并入中山大学生物学系，系所从石牌校区迁往康乐村。</li>
  <li><strong>1960年代初</strong>：南校园415栋生物楼建成，主要作为中山大学生物学系的教学大楼，由此得名“生物楼”。</li>
  <li><strong>1990年代</strong>：伴随学院制教育改革，生物学系发展为<strong>生命科学学院</strong>。校友捐资兴建<strong>曾宪梓南、北两栋教学楼</strong>，逐渐成为学院主要教学场所。</li>
</ul>

<p><strong>文化记忆：</strong></p>
<ul>
  <li>415栋生物楼在数十年的教学历史中，承载了几代中大师生的课堂与实验记忆。</li>
  <li>在<strong>生命科学学院新楼</strong>投入使用之前，它一直是生物学系的核心活动空间。</li>
  <li>随着学科发展与新楼建成，415栋逐渐被师生们亲切称作“<strong>旧生物楼</strong>”。</li>
</ul>`
    },
    {
      id: 26,
      name: '达尔文雕塑',
      position: '南校园生物楼正前方',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_026_charles_darwin_sculpture.jpg',
      description: `<p><strong>达尔文半身雕像</strong>，矗立于中山大学南校园的旧生物楼（即“旧生物楼”—南校园415栋）前，是生命科学学子心中的精神坐标。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>雕像由中山大学生物系1979级校友捐赠，具体捐赠时间为<strong>1983年</strong>。</li>
  <li>该雕像经历逾四十载光阴，一直静静矗立于红砖绿瓦的旧生物楼前，见证着中山大学生命科学的发展步伐。</li>
</ul>

<p><strong>文化意义：</strong></p>
<ul>
  <li>达尔文象征着进化论所倡导的<strong>“开拓、质疑与实证”</strong>的科学精神，是生命科学探索的启蒙象征。</li>
  <li>雕像已成为中大“生科学子”日常打卡与精神寄托的重要场所，激励师生追求真理与创新。</li>
</ul>

<p>📖 <strong>文创延伸：</strong>值此中山大学生物学科百年校庆之际，学院推出以达尔文像为原型的<strong>文创微缩模型</strong>，致敬大师、为母校献礼。</p>`
    },
    {
      id: 27,
      name: '曾宪梓堂',
      position: '南校园425、427号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_027_zeng_xianzhi_hall.jpg',
      description: `<p><strong>曾宪梓堂（Tsang Yam Shee Hall）</strong>，位于中山大学南校园，为生命科学学院的教学、科研与办公大楼。该堂由中大杰出校友、香港金利来集团创办人<strong>曾宪梓博士</strong>慷慨捐建，1990年秋落成，共六层，寓意“风来八面”，象征开放与创新。时任广东省省长<strong>叶选平</strong>亲题“曾宪梓堂”校名。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1990年秋</strong>：堂楼建成落成，作为生命科学学院的重要建筑。</li>
  <li><strong>1993年</strong>：曾宪梓堂南院落成，南院设有朱墙碧瓦，气势恢宏。</li>
  <li>曾宪梓博士还为改善教职工住宿条件，捐建九层教师住宅。</li>
</ul>

<p><strong>建筑与校园意义：</strong></p>
<ul>
  <li>曾宪梓堂是生命科学学院从旧生物楼向现代教学科研转型的重要载体。</li>
  <li>其命名表达学校对校友厚德爱校精神的缅怀与传承。</li>
</ul>

<p><strong>曾宪梓博士简介：</strong></p>
<ul>
  <li>中山大学生物学系动物学专业1961届校友，1993年获中大名誉博士学衔，生命科学学院荣誉院长。</li>
  <li>香港金利来集团创始人，长期关注教育与社会公益，累计捐助中大建设包括曾宪梓堂、南院、中山楼等项目。</li>
</ul>
`
    },
    {
      id: 28,
      name: '蒲蛰龙雕塑',
      position: '曾宪梓堂北侧',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_028_pu_zhelong_sculpture.jpg',
      description: `<p><strong>蒲蛰龙雕塑</strong>，位于<strong>中山大学南校园（生命科学学院片区）</strong>，为纪念著名<strong>昆虫学家、植物保护学家蒲蛰龙先生</strong>而设。雕塑以朴素凝练的写实手法呈现学者风貌，传递<strong>“顺应生态、科学治虫”</strong>的绿色植保理念。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>筹建</strong>：由生命科学学院发起，校友与社会人士共同支持，经学校审批完成设计与铸造。</li>
  <li><strong>落成揭幕</strong>：雕塑安置于学院片区的开放空间，面向主要步行动线，成为校园生态与科学精神的标志点。</li>
  <li><strong>持续维护</strong>：学院定期进行清洁与周边绿化养护，结合新生教育、学术讲座等活动进行科普与传承。</li>
</ul>

<p><strong>艺术特色：</strong>雕塑整体造型稳健含蓄，重在刻画学者气质：神态沉静、目光坚定；衣褶与肌理处理细腻，体现严谨与克制的美学。基座设计简洁有力，便于环植花木与布置科普标识，使纪念与环境相融。</p>

<p><strong>学术与精神：</strong>雕塑所承载的不仅是个人纪念，更是一种面向未来的价值倡导——尊重自然规律、减少化学农药依赖、以生态学原理开展<strong>综合病虫害治理（IPM）</strong>。这一理念在华南农业与生态文明建设中具有深远影响，亦启发学子以科学方法服务民生。</p>

<p>📖 <strong>蒲蛰龙</strong>：著名昆虫学家、植物保护学家，长期从事害虫生态与绿色防控研究，推动综合治理理念在我国的实践与普及；在华南地区高校与科研机构从事教学与科研，培养了大批植保与生命科学人才，被誉为我国<strong>绿色植保的先行者</strong>之一。</p>
`
    },
    {
      id: 29,
      name: '马文辉堂',
      position: '南校园475号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_029_ma_wenhui_hall.jpg',
      description: `<p><strong>马文辉堂（Ma Wenhui Hall）</strong>，原<strong>475号建筑</strong>，现位于<strong>中山大学南校园</strong>，由爱国华侨<strong>马文辉先生</strong>捐资兴建。该楼落成于<strong>20世纪上半叶</strong>，是岭南大学时期的重要红砖建筑之一。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>岭南大学时期</strong>：作为校园红楼群的一部分，用于教学与师生活动。</li>
  <li><strong>1950年代</strong>：岭南大学并入中山大学后，继续作为教学与科研使用。</li>
  <li><strong>1990年代以后</strong>：楼宇逐步改造为<strong>中山大学生物博物馆</strong>所在地。</li>
</ul>

<p><strong>现用功能：</strong>现为<strong>中山大学生物博物馆</strong>，馆藏涵盖<strong>脊椎动物、昆虫、植物、真菌、矿物</strong>等多个门类，收藏量超过<strong>50万件</strong>，其中不乏国家一级保护物种和珍稀标本。生物博物馆不仅是中大生命科学学科的重要教学科研平台，也面向公众开放，承担科普教育职能。</p>

<p>📖 <strong>马文辉</strong>，为旅居海外的<strong>爱国华侨与慈善家</strong>，生前热心支持岭南教育事业。其捐资建造的<strong>“马文辉堂”</strong>，如今承载着中大生物学科的历史记忆与文化传承。</p>`
    },
    {
      id: 30,
      name: '贺丹青堂',
      position: '南校园478号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_030_he_danqing_hall.jpg',
      description: `<p><strong>贺丹青堂（He Danqing Hall）</strong>，原<strong>478号建筑</strong>，现位于<strong>中山大学南校园</strong>。该建筑以旅美爱国华侨<strong>贺丹青先生</strong>之名命名，是岭南大学时期的重要捐建楼宇之一。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>岭南大学时期</strong>：作为校园红楼群的一部分，用于教学和科研。</li>
  <li><strong>1950年代</strong>：岭南大学并入中山大学后，该楼继续为生物学科使用。</li>
  <li><strong>20世纪末</strong>：逐步改造为科研与实验教学基地。</li>
</ul>

<p><strong>现用功能：</strong></p>
<ul>
  <li>为<strong>有害生物控制与资源利用国家重点实验室</strong>所在地。</li>
  <li>实验室聚焦于昆虫学、生态学与资源利用领域，致力于解决农业、林业、公共卫生中的重大害虫防治问题。</li>
  <li>研究方向包括：害虫分子生物学、昆虫-植物互作机制、绿色防控技术以及昆虫资源的综合利用。</li>
  <li>该实验室是国内最早建立的昆虫学与有害生物研究平台之一，在农业害虫<strong>“绿色防控”</strong>方面处于全国领先水平。</li>
</ul>

<p>📖 <strong>贺丹青</strong>，早年旅居海外的<strong>爱国华侨</strong>，长期关心岭南地区教育事业，热心捐助岭南大学校舍建设。为纪念其功绩，学校将此楼命名为<strong>“贺丹青堂”</strong>。</p>`
    },
    {
      id: 31,
      name: '测试大楼',
      position: '南校园471号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_031_test_building.jpg',
      description: `<p><strong>测试大楼（Analysis and Testing Center Building）</strong>，位于<strong>中山大学</strong>，为校级大型公共科研平台——<strong>中山大学分析测试中心</strong>的主体所在地。分析测试中心始建于<strong>1983年</strong>（原名“测试中心”，<strong>2023年9月</strong>更名为“分析测试中心”），是华南地区规模最大、仪器设备先进、综合分析测试能力雄厚的大型理化分析中心之一。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1983年</strong>：中山大学测试中心成立。</li>
  <li><strong>2023年9月</strong>：正式更名为<strong>分析测试中心</strong>。</li>
  <li>经过40年的建设与发展，现已成为学校理、工、医科科研与教学的重要校级大型仪器公共服务平台。</li>
</ul>

<p><strong>平台建设：</strong></p>
<ul>
  <li>下设<strong>广州南校园分中心、广州东校园分中心、深圳校区分中心、珠海校区分中心</strong>，总面积约<strong>12330㎡</strong>。</li>
  <li>平台以“双一流”建设为目标，打造<strong>“平台水平一流、支撑管理一流、分析能力一流”</strong>的校级大型仪器服务体系。</li>
</ul>

<p><strong>队伍建设：</strong></p>
<ul>
  <li>在岗员工共<strong>70人</strong>，其中实验技术人员53人，管理人员2人，自聘人员10人。</li>
  <li>技术队伍整体学历水平高：博士31人、硕士20人，硕博比例<strong>96.2%</strong>。</li>
  <li>职称结构合理：正高5人、副高11人、中级34人。</li>
</ul>

<p><strong>设备资产：</strong></p>
<ul>
  <li>中心仪器设备总值<strong>6.93亿元</strong>。</li>
  <li>500万元以上大型仪器设备<strong>33台套</strong>，包括：冷冻电镜系统、多台透射/扫描电镜、高分辨质谱、ICP质谱、光电子能谱仪、核磁共振波谱仪、X射线衍射仪、X射线显微镜及3.0T磁共振成像系统等。</li>
</ul>

<p><strong>科研与成果支撑：</strong></p>
<ul>
  <li>近五年支撑师生发表高水平论文<strong>1700余篇</strong>。</li>
  <li>近几年年均测试样品数超<strong>8万个</strong>，并保持年增长率不少于<strong>10%</strong>。</li>
</ul>`
    },
    {
      id: 32,
      name: '竹种标本园',
      position: '马文辉堂（475）北侧',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_032_bamboo_grove.jpg',
      description: `<p><strong>竹种标本园（Bamboo Garden）</strong>，位于<strong>中山大学南校园贺丹青堂旁</strong>，是中国国内种类最为丰富的竹类标本园之一，其历史可追溯至<strong>岭南大学时期</strong>。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>20世纪20年代</strong>：由竹类分类学泰斗<strong>莫古礼教授（F. A. McClure）</strong>主持建立，在<strong>冯钦先生</strong>的维护下逐渐成形。</li>
  <li>历经数代生物学系教师努力，从海内外广泛征集竹种，逐步发展成为我国竹类活体模式标本的重要基地。</li>
  <li><strong>2022年</strong>：生命组学教工党支部启动<strong>“竹种测序溯源，献礼康乐百年”</strong>项目，组织师生开展竹类DNA条形码鉴定与挂牌。</li>
  <li><strong>2024年11月6日</strong>：在中山大学百年校庆之际，举行竹种牌揭牌仪式，标志着该项目圆满收官。</li>
</ul>

<p><strong>学术与科研价值：</strong></p>
<ul>
  <li>现已确认涵盖<strong>簕竹属、刚竹属、唐竹属</strong>等十大属系的至少<strong>46个品种</strong>。</li>
  <li>是国内<strong>活体模式标本最多</strong>的竹类园区之一，为华南植物园提供了近半数竹种资源。</li>
  <li>采用DNA条形码技术实现精准鉴定，建立了完整的物种名录与数据库。</li>
</ul>

<p><strong>珍稀植物：</strong></p>
<ul>
  <li><strong>猪血木（Euryodendron excelsum）</strong>：国家一级保护植物，由陈焕镛院士亲自引入。</li>
  <li><strong>焕镛木（Woonyoungia septentrionalis）</strong>：全校唯一株。</li>
  <li>其他稀有物种：大叶木莲、鹅掌楸、大花第伦桃、锡兰杜英、大叶藤黄、越南抱茎茶、红果糙皮茶、小叶买麻藤等。</li>
</ul>`
    },
    {
      id: 33,
      name: '中山楼',
      position: '南校园474号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_033_zhongshan_building.jpg',
      description: `<p><strong>中山楼（Sun Yat-sen Hall）</strong>，位于<strong>中山大学南校园</strong>，是校园标志性建筑之一。该楼由著名爱国华侨、金利来集团创办人<strong>曾宪梓博士</strong>慷慨捐资<strong>1200万元</strong>兴建，于<strong>1999年6月</strong>破土动工，<strong>2001年</strong>交付使用，<strong>2002年11月12日</strong>（中大第78个校庆日）正式落成。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1999年6月</strong>：中山楼开工建设，定位为中山大学党政办公楼。</li>
  <li><strong>2001年</strong>：大楼主体竣工并投入使用。</li>
  <li><strong>2002年11月12日</strong>：值中山大学第78个校庆日，举行隆重的落成典礼。捐献者<strong>曾宪梓博士</strong>亲临现场并献唱，广东省副省长<strong>李鸿忠</strong>出席典礼。</li>
</ul>

<p><strong>建筑特色：</strong></p>
<ul>
  <li>大楼为红砖基调，融合岭南校园风格与现代设计。</li>
  <li>塔楼部分仿照原中山大学钟楼设计，寓意延续百年学府文脉。</li>
  <li>内部功能布局合理，设有会议厅、办公区与接待空间，是学校党政运作的核心场所。</li>
</ul>

<p>📖 <strong>曾宪梓博士（1931–2019）</strong>：中山大学1961届生物学系校友，著名<strong>实业家、慈善家</strong>，金利来集团创办人。曾长期担任全国人大常委、中华全国工商业联合会名誉副主席、香港中华总商会会长等职。他心系教育，累计捐建<strong>曾宪梓堂、中山楼、教师住宅</strong>等多项校园建筑。</p>`
    },
    {
      id: 34,
      name: '梁銶琚堂',
      position: '南校园487号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_034_liang_xiju_hall.jpg',
      description: `<p><strong>梁銶琚堂</strong>，位于<strong>中山大学南校园487号</strong>，是校园标志性建筑之一。该堂于<strong>1982年秋奠基</strong>，<strong>1984年春竣工</strong>，由香港恒生银行有限公司董事、大昌贸易有限公司副董事长<strong>梁銶琚先生</strong>慷慨捐资<strong>港币600万元</strong>兴建。它是改革开放之初，我国高等学校第一座由香港同胞捐赠并以捐资人姓名命名的建筑，开创了教育界引资办学的新模式。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1982年秋</strong>：奠基，由著名建筑专家<strong>林克明教授</strong>设计，广州市第四建筑工程公司四零一施工队承建。</li>
  <li><strong>1984年春</strong>：竣工并投入使用，成为中大校园重要的多功能礼堂。</li>
  <li><strong>1980年代起</strong>：承担学校各类大型典礼、学术报告和文艺演出。</li>
  <li><strong>改革开放初期</strong>：作为高校利用港澳同胞捐赠建楼的首例，意义深远。</li>
</ul>

<p><strong>建筑特色：</strong></p>
<ul>
  <li>占地面积<strong>9300平方米</strong>，建筑面积<strong>4524平方米</strong>。</li>
  <li>整体布局庄重大气，功能多样，能够容纳大中型会议和庆典活动。</li>
  <li>堂内正面墙镶嵌有<strong>《梁銶琚堂记》</strong>，正中央设有<strong>梁銶琚先生半身铜像</strong>。</li>
</ul>

<p>📖 <strong>梁銶琚先生（Leung Kau Kui）</strong>：香港恒生银行董事、大昌贸易有限公司副董事长，杰出的<strong>企业家与慈善家</strong>。他慷慨捐资中山大学，推动了我国高等教育事业的发展。为铭记其功绩，学校在大堂正面镶嵌<strong>《梁銶琚堂记》</strong>，并铸其铜像以昭示后人。</p>
`
    },
    {
      id: 35,
      name: '研究生院',
      position: '南校园493号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_035_yanjiushengyuan.jpg',
      description: `<p><strong>中学第二寄宿舍</strong>，原<strong>74号建筑</strong>，现位于<strong>中山大学西南区493号</strong>。该建筑由<strong>柯林斯（A. S. Collins）</strong>于<strong>1910年</strong>设计，<strong>1911年</strong>落成，捐赠人包括<strong>曾锡周、李富润、万益源、万德源、江昌乐、南隆、陈和成、王尧臣、王迪臣、岑丽南、朱子佩、广恒、张弼士、东兴、朱广兰、简寅初、黄甫田、马培生</strong>等18人。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>作为<strong>岭南大学附属中学</strong>（岭南大学前身，或称预科）的四栋寄宿舍之一，见证了岭南教育早期的发展。</li>
  <li>四栋中学寄宿舍整体呈<strong>雁字形</strong>展开，分布于南北两侧：南楼坐南朝北，北楼坐北朝南，建筑风格相似。</li>
  <li>该宿舍为附中学生学习与生活的重要空间，承载了岭南中学阶段教育的发展历程。</li>
</ul>

<p><strong>建筑特色：</strong></p>
<ul>
  <li>红砖结构，简洁实用，兼具岭南气候特点的通风采光设计。</li>
  <li>与同批建成的三栋寄宿舍（西北区501号、505号、507号）共同构成完整的学生宿舍群。</li>
  <li>建筑布局体现出当时岭南校园教育生活<strong>“学习—生活—宗教”</strong>三位一体的规划理念。</li>
</ul>`
    },
    {
      id: 36,
      name: '张弼士堂',
      position: '南校园486号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_036_zhang_bishi_hall.jpg',
      description: `<p><strong>张弼士堂</strong>，原<strong>92号建筑</strong>，现位于<strong>中山大学西南区486号</strong>。该建筑由<strong>上海布道团建筑师事务所（Mission Architects Bureau, Shanghai）</strong>设计师<strong>埃德蒙兹（Jas. R. Edmunds Jr.）</strong>于<strong>1920年</strong>设计，<strong>1921年</strong>落成。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>捐建资金来自华侨实业家、<strong>张裕葡萄酒创始人张弼士</strong>先生的夫人<strong>张朱澜芝</strong>、儿子<strong>张秩捃</strong>，按其遗愿捐资<strong>7万元</strong>兴建，堂名因此以张弼士之名命名。</li>
  <li>此外，捐款千元以上的还有：（日里）黄锦培，（暹罗）钟聚源，（西贡）刘焕、邱应篆、叶伯行、马培生，（海防）梁焕微、钟锦泉、吴仲旒、谭植三、区学泉等。</li>
  <li><strong>1921年</strong>：岭南大学特设<strong>华侨学校</strong>，专门接收海外华侨子弟归国就读。张弼士堂作为华侨学校校舍，集<strong>教室、办公室、学生宿舍</strong>于一体，教师亦部分居住其中。</li>
  <li>现堂匾“张弼士堂”为著名古文字学家<strong>商承祚先生</strong>所题。</li>
</ul>

<p><strong>人物介绍：</strong></p>
<ul>
  <li>📖 <strong>张弼士（1841–1916）</strong>，广东大埔人，客属华侨实业家与爱国侨领，倡导“实业兴邦”。他先后创办远洋航运公司，打破外资垄断；在烟台投资创办<strong>张裕酿酒公司</strong>，成为中国近代第一个葡萄酒企业。1915年，张裕葡萄酒在<strong>巴拿马万国博览会</strong>上荣获多项大奖，享誉国际。</li>
  <li>📖 <strong>商承祚（1902–1991）</strong>，广东番禺人，著名古文字学家、考古学家、金石篆刻家、书法家。师从罗振玉，21岁即出版<strong>《殷虚文字类编》</strong>，受到王国维等大师赞誉。在中山大学等校任教多年，学术贡献卓著，其篆书艺术被誉为20世纪代表。</li>
</ul>`
    },
    {
      id: 37,
      name: '逸夫楼',
      position: '南校园494号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_037_yifu_building.jpg',
      description: `<p><strong>逸夫文化艺术中心</strong>，位于<strong>中山大学广州校区南校园东南区</strong>，毗邻学一食堂，步行约10–20分钟可达宿舍区，是南校园课室建筑群的重要组成部分。该楼由著名 philanthropist <strong>邵逸夫</strong>先生捐资兴建，因此得名。</p>

<p><strong>历史沿革与定位：</strong></p>
<ul>
  <li><strong>建设背景</strong>：作为南校园核心公共教学楼，旨在缓解教学空间紧张问题，并为师生提供功能齐全的课堂与自习场所。</li>
  <li><strong>命名缘由</strong>：因邵逸夫先生的捐资支持而得名，以彰显其对教育与文化事业的贡献。</li>
</ul>

<p><strong>建筑设计与设施：</strong></p>
<ul>
  <li>采用现代化教学楼设计标准，布局合理，兼顾课堂功能与通行效率。</li>
  <li>设置有防雨连廊、宽敞教室和多功能空间，满足大规模教学与活动需求。</li>
  <li>截至2020年，所有教室均配备<strong>中央空调系统</strong>与<strong>多媒体教学系统</strong>（投影、电子讲台、扩音装置）。</li>
  <li>配置<strong>智能控制系统</strong>，可集中调节灯光与多媒体设备。</li>
</ul>

<p>📖 <strong>邵逸夫（Sir Run Run Shaw，1907–2014）</strong>，著名爱国实业家、慈善家，香港电视广播有限公司（TVB）创办人，<strong>邵氏兄弟电影公司</strong>创办人之一，毕生热心教育与公益事业，累计向中国内地高校捐建了<strong>300余座“逸夫楼”</strong>，被誉为<strong>“当代教育慈善家”</strong>。</p>
`
    },
    {
      id: 38,
      name: '西大操场',
      position: '学一食堂（496）后',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_038_west_field.jpg',
      description: `<p><strong>西大操场</strong>，位于<strong>中山大学广州校区南校园西北区</strong>，建于1945年，紧邻教学楼与学生宿舍，是校园内历史悠久、影响深远的重要运动与集会场地。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>强国强种</strong>：<strong>1912年</strong>，孙中山就任临时大总统后，就立即发布公告提出<strong>“欲图国力之坚强，必先图国民体力之发达”</strong>。</li>
  <li><strong>尚武精神</strong>：<strong>1917年</strong>，随着岭南大学学校建设速度的加快，体育场馆就更加丰富了，当时学校有五个英式足球场，十个篮球场，四个排球场，十五个网球场，一个游泳池和一个带跑道的田径场。</li>
  <li><strong>操场初建</strong>：西大球场的建设与<strong>抗日战争胜利</strong>有关，主要是由<strong>日本战俘劳工</strong>兴建的。<strong>1945年</strong>，抗日战争胜利，岭南大学回迁原址，学校需要开辟新的体育场地，就由日本战俘劳动赎罪，挑泥挖土，将一口大水塘填平，建成西大球场，供岭南大学的师生使用</li>
</ul>
`
    },
    {
      id: 39,
      name: '冼为坚堂',
      position: '南校园260号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_039_xi_weijian_hall.jpg',
      description: `<p><strong>冼为坚堂</strong>，位于<strong>中山大学广州校区南校园260号</strong>，是一座高等学术研究中心的研究大楼，由香港恒生银行董事、慈善家<strong>冼为坚博士</strong>慷慨捐资兴建。该楼主要用于各类学术会议与研究活动的举办，是校园内重要的学术交流与文化场所。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1990年代起</strong>：冼为坚博士作为中山大学基金会主要资助者，多次支持校区建设与教育发展。</li>
  <li><strong>冼为坚堂</strong>的落成，成为学校学术研究与国际交流的重要平台。</li>
  <li>作为高等学术研究大楼，该堂长期用于承办大型学术会议、校级讲座和跨学科研究活动。</li>
</ul>

<p><strong>人物简介：</strong></p>
<ul>
  <li>📖 <strong>冼为坚（David Sin，1929– ）</strong>，祖籍广东佛山，香港著名实业家与慈善家。</li>
  <li>曾任<strong>新世界发展有限公司执行董事</strong>，是协兴建筑有限公司荣誉主席、万雅珠宝有限公司董事长、美丽华酒店企业有限公司副主席。</li>
  <li>长期担任<strong>恒生银行有限公司董事</strong>，并出任<strong>香港中文大学校董</strong>、中山大学荣誉顾问。</li>
  <li>热心公益，支持教育事业，先后资助中山大学、澳门濠江中学等教育机构，是粤港澳地区广受尊敬的慈善家。</li>
</ul>`
    },
    {
      id: 40,
      name: '紫荆园餐厅',
      position: '南校园259号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_040_bauhinia_garden_dining_hall.jpg',
      description: `<p><strong>紫荆园餐厅</strong>，位于<strong>中山大学广州校区南校园东南区（外国语学院后侧）</strong>，是校园内环境优雅、专为正式宴请和早茶而设的餐饮场所，由邵逸夫先生曾资助兴建的紫荆园宾馆内设餐厅得名。</p>

<p><strong>功能定位：</strong></p>
<ul>
  <li><strong>粤菜与早茶</strong>：提供正宗粤式点心与宴席菜肴，尤以早市的点心（早茶）闻名。</li>
  <li><strong>正式宴会场地</strong>：常用于校内师生和访客的正式宴请和校外接待。</li>
</ul>

<p><strong>服务时间：</strong></p>
<ul>
  <li>早市：每日 7:00–9:30。</li>
  <li>午市：每日 11:00–14:00。</li>
  <li>晚市：每日 17:30–21:30。</li>
</ul>`
    },
    {
      id: 41,
      name: '协和神学院建筑群',
      position: '南校园261、265、268号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_041_union_theological_seminary_complex.jpg',
      description: `<p><strong>协和神学院建筑群</strong>，位于<strong>中山大学广州校区南校园东南区</strong>，现存<strong>261号、265号、268号</strong>三栋建筑，落成于<strong>1947–1948年</strong>间。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1914年10月</strong>：协和神学院创办。</li>
  <li><strong>1919年</strong>：岭南大学与协和神学院签订合约，翌年开设<strong>神学预科</strong>。</li>
  <li><strong>抗战胜利后</strong>：协和神学院并入岭南大学，成为五大学院之一，但仍保持独立的办学机构。</li>
  <li><strong>1951年</strong>：协和神学院自岭南大学脱离，复名<strong>“广州协和神学院”</strong>。</li>
</ul>

<p><strong>建筑与功能：</strong></p>
<ul>
  <li><strong>261号楼</strong>：最初为协和神学院的教学与办公场所。</li>
  <li><strong>265号、268号楼</strong>：均曾作为学生宿舍使用。</li>
  <li>建筑整体为20世纪中期岭南校园典型的红砖结构，兼具简洁实用与宗教教育氛围。</li>
</ul>`
    },
    {
      id: 42,
      name: '芙兰堂',
      position: '南校园262号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_042_teaching_building_3.jpg',
      description: `<p><strong>芙兰堂</strong>，原<strong>第三教学楼</strong>，位于<strong>中山大学广州南校园</strong>。因校友<strong>陈运河、刘修婉伉俪</strong>设立“芙兰奖”三十周年纪念，于<strong>2024年11月10日</strong>举行揭牌典礼，更名为“芙兰堂”。堂名寓意“<em>芙蕖清雅，兰香绵长</em>”，承载了校友对母校的深厚情感。</p>

<p><strong>历史渊源：</strong></p>
<ul>
  <li><strong>1995年</strong>：设立物理系<strong>“芙兰励教奖学金”</strong>。</li>
  <li><strong>2009年</strong>：扩展为中山大学“芙兰奖”，覆盖文、理、医等学科。</li>
  <li><strong>2014–2024年</strong>：多次续捐，累计金额超过<strong>人民币四千万元</strong>。</li>
  <li><strong>2024年</strong>：校庆百年之际，第三教学楼更名<strong>“芙兰堂”</strong>。</li>
</ul>

<p><strong>奖项意义：</strong></p>
<ul>
  <li>“芙兰奖”由国学大师<strong>饶宗颐</strong>题字，寓意学术如荷兰般自洁自芳。</li>
  <li>设立至今已奖励<strong>近四千人次</strong>，成为中大师生学术追求的重要动力。</li>
  <li>在科研、教学与文化传承方面产生深远影响。</li>
</ul>

<p>📖 <strong>捐赠人</strong>：陈运河先生（化学系1968届）、刘修婉女士（物理系1969届），三十年来累计捐赠超四千万元。他们以“念恩”为初心，支持人才培养与科研发展，被誉为中国高等教育史上的佳话。</p>`
    },
    {
      id: 43,
      name: '锡昌堂',
      position: '南校园269号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_043_xichang_hall.jpg',
      description: `<p><strong>锡昌堂</strong>，位于<strong>中山大学广州校区南校园</strong>，由校友<strong>邹锡昌</strong>先生捐资<strong>2000万元</strong>建设，建筑面积<strong>11388平方米</strong>。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>2007年10月14日</strong>：锡昌堂奠基仪式举行，作为中山大学<strong>83周年</strong>校庆献礼。</li>
  <li><strong>2008年11月</strong>：正式投入使用。</li>
  <li>主要归属<strong>哲学系</strong>使用，部分空间作为<strong>中山大学博物馆</strong>筹备用房。</li>
</ul>

<p>📖 <strong>捐赠人</strong>：邹锡昌先生，中山大学杰出校友，其慷慨捐资支持学校建设，体现了对母校发展的深厚情谊与对学术文化事业的支持。</p>`
    },
    {
      id: 44,
      name: '四墩楼',
      position: '南校园234-237号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_044_sidun_building.jpg',
      description: `<p><strong>四墩楼</strong>，又称<strong>“炮台屋”</strong>，位于<strong>中山大学广州校区南校园东南区234–237号</strong>，为四栋风格一致的教师住宅，呈平行四边形分布。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>建于20世纪30年代，属康乐园早期建筑群，采用红砖砌筑、砖混结构，局部设有西式壁炉。</li>
  <li>因外观厚重坚固，俗称<strong>“炮台屋”</strong>。</li>
  <li><strong>东南区234号</strong>，现在为<strong>中山大学心理健康教育咨询中心所</strong>使用。</li>
  <li><strong>东南区235号</strong>，现在为<strong>土木工程学院</strong>所使用。</li>
  <li><strong>东南区236号</strong>，现在为<strong>地理科学与规划学院</strong>所使用。</li>
  <li><strong>东南区237号</strong>，现在为<strong>土木工程学院</strong>所使用。</li>
</ul>
`
    },
    {
      id: 45,
      name: '8号住宅',
      position: '南校园240号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_045_residence_no8.jpg',
      description: `<p><strong>8号住宅</strong>，原为岭南大学时期编为<strong>8号的住宅</strong>，现位于<strong>中山大学广州校区南校园东南区240号</strong>。该建筑的具体建造年代和资金来源尚待考证。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1936年前后</strong>，岭南大学的<strong>陈淑仪</strong>和文理学院教育学副教授<strong>李宝荣</strong>曾先后在此居住。</li>
  <li>第二层曾经为<strong>中山大学医院</strong>用房，1994年前后也曾用作教工宿舍。</li>
</ul>`
    },
    {
      id: 46,
      name: '孖屋二',
      position: '南校园241号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_046_twin_house_no2.jpg',
      description: `<p><strong>孖[mā]屋之二</strong>，原<strong>12-13号住宅</strong>，现位于<strong>中山大学南校园东南区241号</strong>。该建筑为<strong>洛克菲勒基金会中国医业董事会（The China Medical Board of the Rockefeller Foundation）</strong>捐建的三栋孖屋形教师住宅之一，于<strong>1920年</strong>落成。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>孖[mā]屋又称“双屋”，两间独立住宅相连成一栋，各有独立入门与楼梯，房间对称分布。</li>
  <li>岭南大学时期建有三栋孖[mā]屋，现仅存两栋，分别为东北区312号与东南区241号。</li>
  <li>曾长期作为教师住宅使用，现为<strong>中山大学博雅学院</strong>所在地。</li>
</ul>

<p><strong>名人轶事：</strong></p>
<p>📖 <strong>陈心陶（1904–1977）</strong>，中国近代<strong>寄生虫学奠基人</strong>，著名血吸虫病防治专家与医学教育家。早年留学美国，在明尼苏达大学和哈佛大学医学院获得硕士与博士学位。归国后任教于岭南大学医学院，主持寄生虫学科建设与研究。</p>
<p>他在华南地区蠕虫区系调查、寄生虫新种发现及<strong>血吸虫病防治</strong>方面作出卓越贡献，提出<strong>“结合农田基本建设消灭钉螺”</strong>的防治对策，推动血吸虫病防治二十余年。其工作受到国家高度重视，生前多次受到中央领导接见。</p>`
    },
    {
      id: 47,
      name: '谭礼庭屋',
      position: '南校园278号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_047_tan_liting_house.jpg',
      description: `<p><strong>谭礼庭屋</strong>，又称<strong>同学屋、同学会屋、岭南同学屋</strong>，原<strong>3-4号住宅</strong>，现位于<strong>中山大学南校园东南区278号</strong>，坐落在怀士堂东南侧。该建筑由岭南大学校董<strong>谭礼庭先生</strong>捐资建造，于<strong>1925年</strong>落成。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>建筑为典型<strong>孖[mā]屋型住宅</strong>，两间独立住宅相连，外观统一大屋顶，各自有独立入门与楼梯，房间分布对称。</li>
  <li>一侧曾作为岭南同学会会所，另一侧作为岭南大学旧同学在校任职者住宅。</li>
</ul>

<p><strong>历史与人物：</strong></p>
<p>📖 <strong>谭礼庭（1876–1966）</strong>，广东新会人，著名航运与实业家，岭南大学校董。</p>
<ul>
  <li><strong>1925年</strong>：将<strong>广南船坞</strong>连同全部设备及部分船只折价售予国民政府，支援海军建设。</li>
  <li><strong>1945年</strong>：抗战胜利后，将矿区余产全部捐赠岭南大学，作为<strong>复校基金</strong>。</li>
</ul>

<p><strong>建筑意义：</strong>“孖屋”作为岭南校园独特的红楼设计形式，既体现中西合璧的建筑特色，又象征了校董与校友对教育的支持。谭礼庭屋不仅是居所，更是岭南教育精神的见证。</p>`
    },
    {
      id: 48,
      name: '马应彪夫人护养院',
      position: '南校园279号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_048_madam_ma_yingbiao_convalescent_home.jpg',
      description: `<p><strong>马应彪夫人护养院</strong>，原<strong>88号建筑</strong>，现位于<strong>中山大学东南区279号A</strong>。该建筑由岭南大学首位华人校董、先施公司创办人<strong>马应彪先生</strong>以其夫人<strong>霍庆棠</strong>的名义捐建，于<strong>1917年</strong>设计，<strong>1919年</strong>落成，设计者为上海布道团建筑师事务所<strong>埃德蒙兹（Jas. R. Edmunds Jr.）</strong>。1990年，其子<strong>马文辉先生</strong>捐资加建一层。</p>

<p><strong>建筑特色：</strong></p>
<ul>
  <li>砖混结构，平顶，四周出檐覆绿琉璃瓦，前设门廊。</li>
  <li>大门两侧嵌有落成纪念石刻：中文为<strong>“马应彪夫人护养院 中华民国七年纪念刻石”</strong>；英文为<strong>“COLLEGE INFIRMARY GIVEN IN HONOR OF HIS WIFE BY MA YING PIV TRUSTEE AD1918”</strong>。</li>
  <li>最初为两层，1990年加建为三层，内设诊症、割症、看护、药剂、特别养病和普通养病房室。</li>
</ul>

<p><strong>历史与人物：</strong></p>
<ul>
  <li>📖 <strong>马应彪（1869–1959）</strong>：广东顺德人，中国近代百货业先驱，先施公司创办人，岭南大学首位华人校董。除捐建护养院，还兴建<strong>马应彪招待室</strong>，并参与捐建<strong>十友堂</strong>。</li>
  <li>📖 <strong>霍庆棠</strong>：牧师霍静山之女，思想新潮，曾拥护孙中山反满革命，是香港妇女运动先驱。她亲自担任先施百货售货员，成为<strong>中国第一位女售货员</strong>，推动社会性别观念的进步。</li>
</ul>`
    },
    {
      id: 49,
      name: '麻金墨屋二号',
      position: '南校园280号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_049_ma_jinmo_house_no2.jpg',
      description: `<p><strong>麻金墨屋二号</strong>，又称<strong>第二麻金墨屋</strong>，原<strong>10号住宅</strong>，现位于<strong>中山大学东南区280号</strong>。该建筑由美国芝加哥慈善家<strong>麻金墨夫人（Mrs. Nettie F. McCormick）</strong>捐建，由<strong>Ng Palk Luen</strong>于1912年设计，<strong>1913年</strong>落成。为区别于她1911年所捐建的另一栋住宅，故称“麻金墨屋二号”。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>初期为岭南大学国文教授、前清秀才<strong>陈辑五</strong>的住宅。</li>
  <li><strong>1931年</strong>：岭南大学副校长<strong>李应林</strong>入驻。</li>
  <li><strong>1936年</strong>：改为<strong>中国员工俱乐部</strong>，作为教职员工聚会与活动场所。</li>
</ul>

<p><strong>人物轶事：</strong></p>
<ul>
  <li>📖 <strong>麻金墨夫人（Mrs. N. F. McCormick）</strong>：美国芝加哥慈善家，她在20世纪初多次捐资岭南大学，为校园建设提供了重要支持。</li>
  <li>📖 <strong>陈辑五（1870–1929）</strong>：岭南大学建校元老之一，中文系主任，基督教牧师。强调<strong>“学以致用”</strong>，推动农业教育普及，长期关心学生成长，并积极参与学校筹款。</li>
  <li>📖 <strong>李应林（1892–1954）</strong>：岭南大学副校长、后任校长，积极扩展学科，奠定岭南大学综合性高等学府地位。</li>
</ul>`
    },
    {
      id: 50,
      name: '怀士堂',
      position: '南校园492号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_050_huaishi_hall.jpg',
      description: `<p><strong>怀士堂</strong>，又称<strong>小礼堂</strong>，是岭南大学康乐园的标志性建筑之一，位于中央大草坪的起点，坐南朝北。建筑整体红灰墙、翠蓝瓦，绿树环绕中显得挺拔典雅。</p>

<p><strong>建筑特色：</strong></p>
<ul>
  <li><strong>外观设计</strong>：背立面呈<strong>不等边五边形</strong>，覆以<strong>斜面琉璃屋顶</strong>，设有三个<strong>八角塔式气窗</strong>，叠加一大两小的中国式悬山尖角屋顶，造型敦厚而不失玲珑。</li>
  <li><strong>正立面</strong>：<strong>哥特式双塔楼</strong>与<strong>中国悬山屋顶</strong>结合的三层建筑，下设地下室。中央三开间高两层门廊，两侧塔楼高三层，塔楼两侧各伸出一层，台顶设露台。</li>
</ul>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1916年</strong>：由美国克里夫兰<strong>史怀士公司（Warner & Swasey Co.）</strong>总裁<strong>安布雷·史怀士（Ambrose Swasey）</strong>捐资修建，作为基督教青年会馆，设有阅览室、游戏室、董事会议室、职员办公室，并兼礼堂之用。为纪念捐资者，命名为“怀士堂”。</li>
  <li><strong>1923年</strong>：孙中山先生与夫人宋庆龄莅临岭南大学，在怀士堂发表演讲，勉励青年学生“<strong>立志要做大事，不可做大官</strong>”。这句名言至今镌刻在怀士堂正门口东侧石壁上。</li>
  <li>此后，怀士堂长期作为岭南大学及中山大学的重要集会、讲座和文化活动场所。</li>
</ul>`
    },
    {
      id: 51,
      name: '鲁迅先生像',
      position: '四墩楼前',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_051_lu_xun_statue.jpg',
      description: `<p><strong>鲁迅先生像（Statue of Lu Xun）</strong>，位于<strong>中山大学广州校区南校园中文堂东南侧</strong>。这尊半身雕像静静伫立，鲁迅身着白色长衫，浓密的八字胡下是对时代的深沉思索，忧郁的眼神中燃着不灭的星火 —— 那是他在此践行“<strong>读书不忘革命，革命不忘读书</strong>”的热忱。</p>

<p><strong>历史背景：</strong></p>
<ul>
  <li><strong>1926年底</strong>：鲁迅应邀南下广州，担任中山大学文学系主任兼教务主任。</li>
  <li>在校仅<strong>70天</strong>，他在大钟楼编写讲义、拟定课表；在学生欢迎会上疾呼“青年要以读书所得为武器，向旧习惯开火”。</li>
  <li>在开学礼上，他以中山先生“革命尚未成功”的遗训激励学子。</li>
  <li>拒绝达官显贵的宴请，却对进步学生送来的革命刊物青眼有加。</li>
  <li><strong>1927年“四一五”事变</strong>后，他为营救学生奔走无果，遂与许寿裳、许广平辞职。</li>
</ul>

<p><strong>精神意义：</strong>雕像凝固的不仅是鲁迅的面容，更是他以笔为戈、以讲台为阵的精神。<br>
“<strong>横眉冷对千夫指，俯首甘为孺子牛</strong>”，在岭南大地上刻下了永不褪色的精神坐标。<br>
今日，当风拂过椰林，仿佛仍能听见他对青年的嘱托 —— “肩起责任向前走，扩大革命的伟力。”</p>
`
    },
    {
      id: 52,
      name: '校训雕像',
      position: '中轴线上怀士堂（492）旁',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_052_school_motto_stone_carving.jpg',
      description: `<p><strong>中山大学校训：博学 审问 慎思 明辨 笃行</strong></p>

<p>这十个字源自<strong>《礼记·中庸》</strong>：“博学之，审问之，慎思之，明辨之，笃行之”。亦为<strong>1924年国立广东大学成立典礼</strong>上孙中山以<strong>大元帅</strong>身份发表的<strong>《训词》</strong>核心内容，自此确立为校训，体现中大对学术精神与人格修养的追求。</p>

<ul>
  <li><strong>博学</strong> —— 广泛学习，兼收并蓄，不断扩展知识边界。</li>
  <li><strong>审问</strong> —— 追根究底，敢于发问，以批判精神探索真理。</li>
  <li><strong>慎思</strong> —— 深入思考，全面权衡，不盲从，不轻信。</li>
  <li><strong>明辨</strong> —— 明察是非，分辨真伪，具备独立判断力。</li>
  <li><strong>笃行</strong> —— 踏实践行，知行合一，把学问付诸行动。</li>
</ul>

<p><strong>成立典礼次序（1924年11月11日 上午九时半）：</strong></p>
<ul>
  <li><strong>（一）集合：</strong> 于大操场齐集。</li>
  <li><strong>（二）升旗礼：</strong> 奏乐 → 升旗 → 欢呼 → 鸣炮。</li>
  <li><strong>（三）大堂行礼：</strong> 奏国乐 → 向国旗三鞠躬 → 校长宣布 → <strong>大元帅训词</strong>（校训出处）→ 祝词 → 演说 → 答词 → 奏乐 → 礼成。</li>
  <li><strong>（四）附属学校庆祝：</strong> 附中在至公堂，附师在雨操场，附小亦在雨操场举行庆祝式。</li>
  <li><strong>（五）摄影：</strong> 全体合影（1尺6相片）；教职员合影（1尺相片）。</li>
  <li><strong>（六）茶会：</strong> 来宾由招待员引座；教职员在膳堂，学生分发茶券。</li>
  <li><strong>（七）展览：</strong> 上午8:00–11:00、下午1:00–4:00，三院相同。</li>
</ul>

<p>百余年来，中大人以此校训为精神坐标，将学术研究与社会责任相结合，在医学、科学、人文学科等领域不断追求卓越。</p>
`
    },
    {
      id: 53,
      name: '希伦高屋',
      position: '南校园305号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_053_xi_lungao_house.jpg',
      description: `<p><strong>希伦高屋</strong> 由美国慈善家 <strong>海伦·希伦高女士（Miss Hellen Gould）</strong> 捐建，是岭南大学康乐园内的重要教师住宅之一。自落成以来，这里先后成为多位中外知名学者的寓所，见证了岭南学术文化的发展历程。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>民国时期</strong>：岭南大学蚕桑科主任 <strong>夏活教授（Charles Walter Howard）</strong>、古尔教授、冯世安教授等人先后在此居住。夏活不仅主持岭南大学蚕桑科，还兼任广东全省蚕丝改良局局长，他深入顺德等地调查，推动了华南蚕丝改良事业。</li>
  <li><strong>1952年院系调整后</strong>：数学家 <strong>姜立夫教授</strong>、昆虫学家 <strong>蒲蛰龙院士</strong>、生物学家 <strong>江静波教授</strong> 等先后居住在此，使得这栋小楼成为中山大学学术群贤荟萃的地方。</li>
</ul>

<p><strong>名人轶事：</strong></p>
<ul>
  <li><strong>姜立夫（1890–1978）</strong>：中国最早的<strong>数学博士</strong>之一，南开大学数学学科的开创者，培养了陈省身、江泽涵、吴大任等一大批数学名家，也是吴大猷、<strong>杨振宁</strong>的数学启蒙老师。</li>
  <li><strong>蒲蛰龙（1912–1999）</strong>：被誉为<strong>“华南生物防治之父”</strong>，首创中国稻田病虫害综合防治模式，推广“以虫治虫、以菌治虫”，在害虫生物防治与综合防治领域成就卓著。</li>
  <li><strong>夏活教授</strong>：美国学者，岭南大学<strong>蚕桑科主任</strong>，深入农村进行蚕桑改良实践，被视为岭南地区现代丝业推广的重要推动者。</li>
</ul>`
    },
    {
      id: 54,
      name: '黑石屋',
      position: '南校园306号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_054_blackstone_house.jpg',
      description: `<p><strong>黑石屋</strong>，原<strong>11号住宅</strong>，现位于<strong>中山大学东北区306号</strong>。该楼由美国芝加哥的<strong>伊沙贝·布勒斯顿（Mrs. I. F. Blackstone）</strong>夫人捐建，由<strong>纽约斯道顿建筑师事务所（Stoughton & Stoughton Architects）</strong>设计，于<strong>1913年开工，1914年落成</strong>，并以捐建者姓氏命名。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>初为岭南学校教工宿舍，后成为岭南大学首任华人校长<strong>钟荣光</strong>的寓所。</li>
  <li><strong>1922年6月18日</strong>：陈炯明叛变期间，宋庆龄曾被钟荣光接至黑石屋避难，成为岭南大学守护革命的重要见证。</li>
  <li><strong>1923年12月21日</strong>：孙中山莅临岭南大学演讲，号召青年<strong>“立志要做大事，不可要做大官”</strong>。演讲后，孙中山到黑石屋与师生座谈，并抨击英美干涉中国内政的<strong>“炮舰政策”</strong>。</li>
  <li><strong>1988年</strong>：岭南大学香港同学会募款重修黑石屋。</li>
</ul>

<p><strong>建筑特色：</strong> 黑石屋是一栋中西合璧的红砖建筑，兼具岭南风格与西式格局。外观简洁而典雅，内部设有壁炉等西式元素，反映了20世纪初岭南校园建筑的多元特征。</p>

<p><strong>现状：</strong> 如今，黑石屋作为<strong>中山大学贵宾楼</strong>，主要用于接待学校贵宾与举办重要会议，平日并不对外开放。它不仅是岭南大学与中山大学发展史上的见证，更是中国近现代教育与革命历史的珍贵遗产。</p>
`
    },
    {
      id: 55,
      name: '麻金墨屋一号',
      position: '南校园309号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_055_ma_jinmo_house_no1.jpg',
      description: `<p><strong>麻金墨屋一号</strong>，原<strong>1号住宅</strong>，现位于<strong>中山大学东北区309号</strong>。该楼由美国芝加哥慈善家<strong>麻金墨夫人（Mrs. Nettie F. McCormick）</strong>于<strong>1911年</strong>捐建，为纪念其丈夫而命名“麻金墨屋”。1913年她又捐建一幢住宅，为区别之，后称此楼为“麻金墨屋一号”。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>初为岭南学堂附属中学校长、岭南大学图书馆馆长<strong>葛理佩（Henry B. Graybill）</strong>的住宅。</li>
  <li>其后，多位著名学者曾在此居住，包括<strong>周寿恺、陈寅恪、王起（王季思）、杨荣国、容庚、商承祚</strong>等。</li>
  <li><strong>1953年夏至1969年春</strong>：二楼为<strong>陈寅恪先生</strong>寓所，他在此完成《论再生缘》《柳如是别传》等重要学术著作。</li>
  <li><strong>2009年11月12日</strong>：辟为<strong>陈寅恪故居</strong>，楼匾由国学大师<strong>饶宗颐先生</strong>题写。</li>
</ul>

<p><strong>建筑与文化：</strong> 麻金墨屋一号为红砖结构，格局朴素典雅。屋前小径曾因<strong>陈寅恪先生</strong>双目失明，被特别刷成白色以便辨认，东侧路口也加装栅栏以保障安全。这些细节，成为中大师生传颂的佳话。</p>

<p><strong>陈寅恪先生（1890–1969）：</strong></p>
<ul>
  <li>中国近现代最负盛名的史学家、古典文学研究家、语言学家与诗人。</li>
  <li>与叶企孙、潘光旦、梅贻琦并称<strong>“清华四大哲人”</strong>，与吕思勉、陈垣、钱穆并称<strong>“前辈史学四大家”</strong>。</li>
  <li>治学严谨，学识渊博，其<strong>佛教史、西域民族史、魏晋南北朝史、隋唐史</strong>等研究影响深远。</li>
  <li>先生生命最后十六年在此楼度过，当时先生已失明，所成的多部学术成果在学生的帮助下<strong>口述编写</strong>而成，留下<strong>“独立之精神，自由之思想”</strong>的学术丰碑。</li>
</ul>
`
    },
    {
      id: 56,
      name: '美臣屋二号',
      position: '南校园304号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_056_meichen_house_no2.jpg',
      description: `<p><strong>美臣屋二号</strong>，原<strong>19号住宅</strong>，现位于<strong>中山大学东北区304号</strong>。该楼为美国慈善家<strong>George Grant Mason</strong>捐建的两栋教师住宅之一，于<strong>1919–1920年</strong>间落成，稍晚于美臣屋一号。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>原为两层建筑，设有地下室和阁楼，曾有双层屋檐，后首层屋檐拆除。</li>
  <li><strong>1936年前后</strong>：岭南大学历史政治系教授兼系主任<strong>包令留（Henry C. Brownell）</strong>曾在此居住。</li>
  <li>其后，<strong>Ruth L. Gills</strong> 与英语系卢施博士亦曾在此居住。</li>
  <li>新中国成立后，著名眼科学家<strong>陈耀真</strong>与<strong>毛文书</strong>夫妇亦居于此楼。</li>
  <li>现为<strong>中山大学廉政与治理研究中心</strong>。</li>
  <li><strong>2000年</strong>：被广州市城市规划局列入“近代、现代优秀建筑群体保护名录”。</li>
  <li><strong>2002年7月</strong>：由广东省人民政府公布为<strong>广东省文物保护单位</strong>。</li>
</ul>

<p><strong>陈耀真与毛文书夫妇：</strong></p>
<ul>
  <li><strong>陈耀真（1899–1986）</strong>：广东台山人，著名眼科学家、医学教育家，获美国波士顿大学医学博士学位，并在霍普金斯大学威尔玛眼科研究所从事研究。1934年毅然回国投身医学教育。</li>
  <li><strong>毛文书（1910–1988）</strong>：四川乐山人，眼科学者。与陈耀真并肩奋斗，一生致力于防盲治盲。</li>
  <li>夫妇二人被誉为<strong>“中国眼科界的居里夫妇”</strong>。</li>
  <li>1950年起在岭南大学医学院任教，1965年创办<strong>中山医学院眼科医院</strong>，这是中国高校第一所附属眼科医院，后发展为<strong>中山眼科中心</strong>。</li>
  <li>陈耀真逝世时，国际眼科界在第25届世界眼科大会闭幕式上全体起立默哀，以纪念其卓越贡献。</li>
</ul>`
    },
    {
      id: 57,
      name: '神甫屋',
      position: '南校园303号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_057_priest_house.jpg',
      description: `<p><strong>神甫屋</strong>，又称<strong>马利诺堂</strong>，是康乐园内唯一一栋由<strong>天主教会</strong>建造并用于传播宗教教义的建筑。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>建造背景</strong>：由天主教<strong>马利诺会（Maryknoll Fathers）</strong>资助兴建，作为岭南大学中从事布道与教育的神职人员住所。</li>
  <li><strong>最初住客</strong>：工学院工程力学课教师<strong>韩德礼神甫（Joseph A. Hahn）</strong>与社会学系教师<strong>潘德民神甫（George N. Putnam）</strong>。</li>
  <li><strong>1953年11月12日—1994年11月</strong>：改作<strong>中山大学孙中山纪念馆</strong>，展出孙中山先生的生平事迹，成为重要的爱国主义教育基地。</li>
  <li><strong>1994年至今</strong>：现为<strong>中山大学保卫处</strong>办公楼。</li>
</ul>

<p><strong>建筑特色：</strong></p>
<ul>
  <li>红砖立面，屋顶简洁，兼具岭南大学红楼群的校园风格与宗教建筑的肃穆气质。</li>
  <li>外观小巧而庄重，见证了康乐园中西文化、宗教与教育的交织。</li>
</ul>`
    },
    {
      id: 58,
      name: '积臣屋',
      position: '南校园308号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_058_jichen_house.jpg',
      description: `<p><strong>积臣屋</strong>，又译<strong>杰克逊屋、泽臣屋、则臣屋</strong>，原<strong>20号住宅</strong>，现位于<strong>中山大学东北区308号</strong>。该楼由时任岭南学校董事会主席<strong>积臣先生（Samuel Macauley Jackson）</strong>捐建，美国纽约<strong>斯道顿建筑师事务所（Stoughton & Stoughton Architects）</strong>于1910年设计，<strong>1912年落成</strong>。积臣先生逝世后，董事会为纪念其贡献，将此楼命名为“积臣屋”。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1912年</strong>：建成后作为岭南学校校长<strong>晏文士博士（Dr. Charles K. Edmunds）</strong>的住宅。</li>
  <li><strong>20世纪30年代</strong>：曾作为<strong>美国基金委员会办事所</strong>。</li>
  <li><strong>1936年前后</strong>：改作<strong>教务长办公室与西童学校</strong>。</li>
  <li><strong>1992年</strong>：学校筹资为该楼<strong>加建一层</strong>。</li>
</ul>

<p><strong>建筑特色：</strong> 积臣屋为红砖结构，立面典雅，屋顶简洁，延续岭南校园红楼群的风格。建筑既体现了中西融合的特色，又因其校长宅邸、办事机构和教务功能的多重身份而具独特的历史地位。</p>
`
    },
    {
      id: 59,
      name: '英东体育馆',
      position: '南校园302号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_059_yingdong_stadium.jpg',
      description: `<p><strong>英东体育馆</strong>位于中山大学广州校区南校园西南侧，坐落于英东田径场东侧，是校园内标志性的现代体育建筑。该馆由香港著名实业家、慈善家<strong>霍英东先生</strong>捐资兴建，因而命名为“英东体育馆”。其于<strong>1990年动工，1991年建成投入使用</strong>，既是中大师生开展体育活动的重要场所，也曾承办过多项大型体育赛事和文艺活动。</p>

<p><strong>建筑特色：</strong>英东体育馆为大跨度钢架结构，内部空间开阔，采光良好，馆内设有篮球、排球、羽毛球等多功能运动场地，可容纳数千名观众。外观以白色立面配合弧线型屋顶，简洁大方而富有现代感，与周边的英东田径场、绿荫环境相映成趣。</p>

<p><strong>历史与功能：</strong></p>
<ul>
  <li><strong>1991年</strong>：落成启用，成为当时华南地区规模领先的现代化大学体育馆。</li>
  <li><strong>1990年代至今</strong>：除日常教学、训练和学生文体活动外，还承办过校运会开幕式、篮球联赛、毕业典礼、文艺晚会等重要活动。</li>
</ul>

<p>🏆 <strong>“倒挂金钩”雕塑：</strong>英东体育馆前广场立有一尊名为<strong>《倒挂金钩》</strong>的青铜雕塑，创作于<strong>20世纪90年代</strong>。雕塑主体为一名正在空中完成倒挂金钩动作的足球运动员，动感线条展现了运动员身体的瞬间力量与张力，象征着中大学子勇于拼搏、敢于挑战的体育精神。这尊雕塑不仅是校园体育文化的象征，也是南校园极具辨识度的地标之一。</p>
`
    },
    {
      id: 60,
      name: '新女学',
      position: '南校园210号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_060_new_womens_school.jpg',
      description: `<p><strong>新女学</strong>，又称<strong>“广寒宫”</strong>，由广东信托公司建筑师<strong>黄玉瑜</strong>设计，于<strong>1929年</strong>落成。岭南大学早在20世纪初即开中国近代教育男女同校之先河。随着女学生人数的增加，旧女学卡彭特楼已不敷使用，因此筹款兴建新女生宿舍，相对于之前的“旧女学”而称“新女学”。</p>

<p>该楼建设资金一部分由岭南大学美国基金会在美国友人中募捐，另一部分由岭南大学首任华人校长<strong>钟荣光</strong>在广东发动华人妇女认捐，其中约半数费用由美国新泽西州柯兰城（Orange Wing）捐出。建筑耗资<strong>18万元</strong>，总面积<strong>2922.6平方米</strong>（含地下室）。</p>

<p><strong>“新女学”</strong>作为岭南大学校园内专门为女生设立的宿舍，承载了学校对<strong>女性教育的重视与承诺</strong>，因此在校史中被亲切称为<strong>“广寒宫”</strong>。它不仅是一栋宿舍楼，更是岭南大学乃至中山大学男女同校、教育平权的重要见证。</p>

<p>🏫 <strong>现状：</strong>如今，“新女学”作为<strong>研究生宿舍</strong>继续使用，依旧为学子们提供温馨安宁的生活与学习空间。</p>`
    },
    {
      id: 61,
      name: '“摇篮”铜像',
      position: '园东湖南岸',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_061_cradle_bronze_statue.jpg',
      description: `<p><strong>“摇篮”铜像</strong>静静伫立于康乐园东湖畔，宛如一段深情往事的凝固。它诞生于<strong>中山大学建校七十七周年</strong>之际，由<strong>海内外17个校友会</strong>共同捐资铸就，以此寄托校友们对母校的绵长眷恋，象征中山大学作为人才培育摇篮的深厚底蕴。</p>

<p><strong>雕塑设计：</strong></p>
<ul>
  <li><strong>底座</strong>：采用<strong>棕红色圆柱</strong>，沉稳厚重，与校园的红墙绿瓦相互映衬，仿佛自诞生之初便与康乐园融为一体。</li>
  <li><strong>铜牌</strong>：底座前后镶嵌黄色方形铜牌，其上镌刻着校友们对母校的礼赞与感恩，字字句句承载着一段段捐赠背后的深情。</li>
  <li><strong>母子雕像</strong>：底座之上为母子相拥相偎的铜像造型。雕塑未作细致写实的刻画，而是以<strong>流畅舒展的弧形线条</strong>勾勒母子的温馨姿态。简洁的轮廓、和谐的比例与韵律之美，传递出跨越时光的温暖与依靠。</li>
</ul>

<p><strong>象征意义：</strong>“摇篮”不仅是一件雕塑，更是一份文化印记。它诉说着中大作为<strong>人才摇篮</strong>的使命与担当，也映照出校友对母校的无限眷恋与深情。</p>
`
    },
    {
      id: 62,
      name: '冼星海半身铜像',
      position: '园东湖北岸',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_062_xian_xinghai_bust.jpg',
      description: `<p><strong>冼星海雕像（Statue of Xian Xinghai）</strong>坐落于中山大学广州校区南校园东湖北岸，宛如一位永恒的守望者，静静凝望着这片他曾挥洒青春与理想的土地。</p>

<p>雕像以汉白玉精心雕琢，由岭南大学香港校友敬献，雕塑家<strong>曹崇恩</strong>与<strong>鹿惠兰</strong>合力创作，于<strong>1984年11月2日</strong>落成。整体造型中，冼星海身姿挺拔，右手紧握的小提琴仿佛仍蓄满了跃动的音符，双眼目光灼灼，既展现出对音乐艺术的执着追求，又饱含着对民族命运的深切关怀。</p>

<p><strong>人物精神映照：</strong></p>
<ul>
  <li>那目光中，可以看到他在巴黎勤工俭学时忍饥挨饿却坚持创作的倔强；</li>
  <li>可以看到他在延安窑洞油灯下谱写<strong>《黄河大合唱》</strong>时的激情澎湃；</li>
  <li>更能看到他用旋律唤醒民众、鼓舞抗战士气的赤诚。</li>
</ul>

<p><strong>历史印记：</strong> 雕像底座背面镌刻着他的生命轨迹——自<strong>1918年</strong>踏入岭南大学义学开启求学之路，到附中、预科时期凭借出色的单簧管技艺赢得“南国箫手”的美誉，再到赴京、沪、巴黎深造，最终成为用音乐为民族呐喊的先锋。他在康乐园的身影历历可见：义务教乡村孩子唱歌的温暖午后，与钟敬文探讨古诗与音乐的夜晚，以及抗战烽火中用《黄河大合唱》点燃亿万人民斗志的瞬间。</p>

<p><strong>精神意义：</strong> 如今，每当东湖的微风拂过雕像的衣角，仿佛仍能听见他指挥乐队时的激昂节奏，仍能感受到他<strong>将个人命运与家国兴衰紧紧相连的滚烫初心</strong>。这尊雕像不仅是对一位音乐大师的纪念，更是康乐园里一处鲜活的精神地标，提醒着每一位中大学子：<em>何为用热爱点亮理想，以赤诚报效家国。</em></p>`
    },
    {
      id: 63,
      name: '翘燊堂、文虎堂',
      position: '南校园116、118号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_063_qiaoshen_hall_and_wenhu_hall.jpg',
      description: `<p><strong>翘燊堂（Kiw San Hall）</strong>由澳门著名人士<strong>李翘燊</strong>捐建，落成于<strong>1933年</strong>。1931年前后，岭南大学为解决附属中学校舍紧张问题，决定筹款兴建新中学，先后建成五栋建筑，形成新中学建筑群。现存三栋，其余两栋分别为<strong>文虎堂</strong>和<strong>中学新教室（园东区110号）</strong>。翘燊堂坐北朝南，为三层建筑，楼匾“翘燊堂”三字由<strong>南海冯愿</strong>于1934年10月题写。</p>

<p><strong>李翘燊</strong>是澳门著名赌商李光的长子，年少便才名显赫，22岁时即“按例位列翰林”，并创造了澳门开埠以来的两项独特纪录：其一，成为澳门唯一在科举会试中中进士的本埠人士；其二，作为澳门出身的最显赫的朝廷命官。同时，由于他加入了葡萄牙籍，他也成为“中国历史上唯一一位葡萄牙籍的翰林院编修”。</p>

<hr/>

<p><strong>文虎堂（Boon Haw Hall）</strong>由新加坡华侨企业家<strong>胡文虎</strong>兄弟捐赠，落成于<strong>1933年</strong>。1951年一度更名为<strong>仲恺堂</strong>，1981年恢复原名。文虎堂坐南朝北，原为三层建筑，1947年加建一层。楼匾“文虎堂”三字同样由<strong>南海冯愿</strong>于1934年题写。</p>

<p><strong>胡文虎（1882–1954）</strong>，福建永定下洋中川村人，著名华侨企业家、报业家和慈善家，被誉为<strong>“南洋华侨的传奇人物”</strong>。他以制药业起家，研制出的<strong>“万金油”</strong>等成药享誉全球，使其赢得“万金油大王”的美誉，成为亿万富翁。他同时在报业上独资创办十多家中英文报纸，包括《星岛日报》《星洲日报》，一度享有“报业巨子”的称号。这些报纸不仅传播新闻，也积极宣传抗日救国，凝聚华侨力量，鼓舞民族信心。</p>

<p><strong>爱国与慈善：</strong>胡文虎一生热心公益，出资兴办医院、学校、体育馆，赈济灾民，为抗日军队捐赠巨额财物。他的慈善事业遍布中国、马来西亚、新加坡等地，其中中国为主要受捐国，占比高达49%。</p>

<p><strong>历史争议：</strong>尽管胡文虎在抗日战争期间的“东京之行”曾引发争议，被部分人质疑“媚敌”，但更多史料显示，他的举动更多是出于缓解香港民食恐慌及维护华侨合法权益的考虑。他的一生既是商业传奇，也是近现代华侨爱国与慈善精神的缩影。</p>
`
    },
    {
      id: 64,
      name: '松涛园',
      position: '南校园359号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_064_songtao_garden.jpg',
      description: `<p><strong>松涛园食堂</strong>，2020年正式亮相，是校园生活区与教学区之间的重要枢纽。该食堂于2023年以全新面貌落成，总建筑面积达<strong>24031.1平方米</strong>，设有地上五层与地下1层，餐位数<strong>4600个</strong>，是南校园规模最大、功能最齐全的学生餐厅。</p>

<p>建筑外观延续了岭南传统的<strong>红墙碧瓦</strong>风格，并融入现代弧线设计，外形大气典雅，已成为南校园的新地标。内部装修整洁明亮，配备电梯、智能结算系统及无障碍设施，为师生提供舒适便捷的就餐体验。</p>

<ul>
  <li><strong>负一层</strong>：设有后厨与食材储藏空间，保证食材新鲜与食品安全。</li>
  <li><strong>一层</strong>：提供大众分餐、腊味套餐、东南亚美食、西式套餐等，配有茶饮吧与小卖部，可同时容纳<strong>864人</strong>就餐。</li>
  <li><strong>二层</strong>：拥有<strong>1032个餐位</strong>，主打特色自选餐，菜品丰富，性价比高。</li>
  <li><strong>三层</strong>：汇聚地方风味与国际料理，包括<strong>粤式小炒、川湘菜、潮汕美食、日韩料理、东北饺子</strong>等。</li>
  <li><strong>四层</strong>：设有<strong>550个餐位</strong>，分为中餐厅与西餐厅，并提供东南亚料理与时尚自助餐。</li>
  <li><strong>五层</strong>：设有面点制作间与功能区，视野开阔，环境温馨。</li>
</ul>

<p><strong>运营时间：</strong><br>
早餐 6:30–9:30<br>
午餐 11:00–13:30<br>
晚餐 17:00–19:30</p>

<p>松涛园食堂不仅是一处就餐场所，更是展现“<strong>食在中大</strong>”文化的重要窗口。它以合理的空间布局、多元的菜品选择和现代化的管理，充分体现了中大对师生日常生活的用心关怀。</p>`
    },
    {
      id: 65,
      name: '新体育馆',
      position: '南校园369号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_065_new_gymnasium.jpg',
      description: `<p><strong>中山大学体育馆</strong>，位于<strong>广州大学城中山大学新校区主轴线南端</strong>，北邻图书馆，南接大学城中环路。建筑面积约<strong>11600平方米</strong>，包括主馆及三层副馆，按国际比赛标准建造，可容纳<strong>5000名观众</strong>，其中设有1700余个可伸缩座椅。</p>

<p>体育馆整体设计现代化，功能完善，采用<strong>K-13植物纤维材料天花板</strong>，兼具隔热与吸音功能，内部通风与采光良好，地面铺设优质枫木地板，满足国际级赛事对场地的要求。场馆配备<strong>高标准灯光、音响系统与电子显示屏</strong>，并设有新闻中心、兴奋剂检测中心、裁判与运动员休息室、洗浴间等功能区域。</p>

<p>作为广州大学城的重要体育地标，该馆不仅服务于中山大学的体育教学与学生活动，也对社会开放，曾作为<strong>第八届全国大学生运动会排球主赛场</strong>，并承办了<strong>2010年广州亚运会排球比赛（11月13日至11月27日）</strong>与<strong>2010年亚残运会硬地滚球比赛（12月13日至12月18日）</strong>。此外，它还承接各类文艺演出、社会集会和大型活动，成为校内外多元化公共服务的重要场所。</p>

<p>这座体育馆与周边的体育设施共同构成中山大学的综合体育体系，是集<strong>教学、训练、竞赛与社会服务</strong>于一体的现代化场馆，也是广州大学城的建筑亮点之一。</p>
`
    },
    {
      id: 66,
      name: '松园湖',
      position: '善思堂（386）旁',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_066_songyuan_lake.jpg',
      description: `<p><strong>松园湖</strong>，位于中山大学广州校区南校园东北部，毗邻松园，因而得名，又称“松园湖”。</p>

<p>康乐园自岭南大学时期起便以园林景致著称，昔日共有十三处湖泊池沼，现仅存四个，被称为<strong>“中大四湖”</strong>，分别是<strong>东湖、西湖、北湖与松园湖</strong>。它们以方位命名，各具特色：东湖荷花摇曳、绿树环绕；北湖方池整齐，大王椰肃立池畔；西湖碧水映照玉色三孔桥；松园湖则以松林相依，宁静雅致。</p>

<p>作为“中大四湖”之一，松园湖与周边的松园建筑群、翠竹绿植相映成趣，湖水清澈，倒影悠然。这里不仅承载了岭南园林的典雅气韵，也是学子散步、交流与静思的理想之所，见证着百年康乐园的历史与人文积淀。</p>`
    },
    {
      id: 67,
      name: '第二教学楼',
      position: '南校园389号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_067_teaching_building_2.jpg',
      description: `<p><strong>第二教学楼（389栋）</strong><br>
中山大学广州校区南校园北侧的第二教学楼，现为公共教学的重要场所。该楼始建于上世纪，2022年7月起学校对其进行全面翻新改造，改造面积约1.7万㎡，于2023年焕新亮相。</p>

<p>整栋建筑共有6层，其中1-3层为公共课室区域，分为<strong>讲授型课室、研讨型课室和阶梯课室</strong>，满足不同的教学需求：</p>
<ul>
  <li><strong>讲授型课室</strong>：配备4-6块推拉式黑板、主投影设备和双侧大屏幕，确保所有同学都能清晰看到课件内容。</li>
  <li><strong>研讨型课室</strong>：分组操作台与可触摸大屏幕，支持师生互动和小组讨论，激发创造与交流。</li>
  <li><strong>阶梯课室</strong>：设有互联白板与实时投屏系统，教师摆脱粉笔灰，学生享受沉浸式学习体验。</li>
</ul>

<p>此外，二教还配备<strong>公共绘图室</strong>（305、307室），拥有可升降绘图桌，为工科学生提供良好的支持。</p>

<p><strong>亮点与配套</strong></p>
<ul>
  <li>课室门口设有<strong>电子班牌</strong>，实时显示课程信息；</li>
  <li>所有课室均设<strong>可升降讲台</strong>，为教师和学生提供更舒适的使用体验；</li>
  <li>配备<strong>云录播系统</strong>，支持线上线下同步教学。</li>
</ul>`
    },
    {
      id: 68,
      name: '卡彭特楼',
      position: '南校园378号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_068_carpenter_building.jpg',
      description: `<p><strong>卡彭特楼（Carpentier Hall）</strong><br>
卡彭特楼因美国纽约<strong>豪拉斯·卡彭特将军</strong>（Horace Carpentier）遗赠2.5万美元而建，由<strong>纽约斯道顿建筑师事务</strong>所于1910年设计，1911年落成。原为岭南学堂医院楼，后改作女生第一宿舍，因在新女学（广寒宫）建成后而被称为“旧女学”。</p>

<p>岭南大学在20世纪初便开创中国近代教育<strong>男女同校</strong>的先河。早期未设女生宿舍时，女学生寄宿于钟荣光校长寓所。随着女生人数增加，卡彭特楼成为她们的首个宿舍楼，具有重要的教育史意义。</p>

<p>1934—1936年前后，卡彭特楼改为岭南医院护士学校，随后又作教师宿舍使用。著名植物学家、学部委员<strong>陈焕镛</strong>先生曾在此创办植物研究所，该所即为中国科学院华南植物研究所的前身。</p>

<p><strong>学术人物——陈焕镛（1890—1971）</strong><br>
陈焕镛是中国近代植物分类学的开拓者和奠基人之一，他发现并命名了上百个植物新种，建立了10余个新属。1957年，他主持创建了<strong>华南植物园</strong>与鼎湖山树木园，推动了中国植物学的系统发展。他毕生致力于开发利用和保护植物资源，在科研、机构建设、标本搜集和人才培养方面贡献卓著，被誉为“华南植物学之父”。</p>

<p>卡彭特楼不仅是一座历史建筑，更见证了岭南大学在教育平权、医学与植物学研究上的重要历程。</p>
`
    },
    {
      id: 69,
      name: '林护堂、黄铭衍堂、黄传经堂',
      position: '南校园392号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_069_linhu_hall_huang_mingyan_hall_huang_chuanjing_hall.jpg',
      description: `<p><strong>林护堂</strong>建于1933年，由香港实业家、慈善家<strong>林护</strong>先生（Lam Woo, 1871–1933）捐资兴建，以其名字命名。林护曾任香港大学校董，热心支持教育，是当年港澳华人社会最主要的教育捐助者之一。林护堂最初作为岭南大学附属中学校舍，长期服务于岭南中学教育。</p>

<h3>铭衍堂（Ming Yeen Hall）</h3>
<p>铭衍堂建于1933年，由华侨企业家<strong>胡文虎、胡文豹</strong>兄弟捐资。二人以<strong>“虎标万金油”</strong>闻名，并广泛投入慈善与教育事业。铭衍堂为岭南大学中学新校舍之一，延续岭南校园红砖绿瓦的建筑风格，成为当时岭南中学重要的教学设施。</p>

<h3>黄传经堂（Wong Chuen King Hall）</h3>
<p>黄传经堂同样建于1933年，由旅港实业家<strong>黄传经</strong>先生捐资兴建。建筑落成后长期作为岭南大学中学教学场所，与林护堂、铭衍堂并列为岭南中学新校舍群，体现了华侨支持教育的热情。</p>

<h3>现状</h3>
<p>林护堂、铭衍堂与黄传经堂原属岭南大学<strong>中学新校舍群</strong>，与翘燊堂、文虎堂等共同组成<strong>岭南大学中学建筑群</strong>。如今，这三栋建筑已合并使用，统称为<strong>中山大学第六教学楼</strong>，继续承担教学任务。它们不仅是功能性的教学空间，更是岭南大学侨资兴学、爱国助教传统的历史见证。</p>
`
    },
    {
      id: 70,
      name: '叶葆定堂',
      position: '南校园394号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_070_ye_baoding_hall.jpg',
      description: `<p><strong>叶葆定堂</strong>位于中山大学岭南（大学）学院，由岭南学院名誉主席、名誉教授<strong>叶葆定先生</strong>（1908—2008）慷慨捐资兴建，以其名字命名。大楼为<strong>岭南国际MBA教育中心</strong>的核心建筑，承载着岭南学院对国际化商学教育的探索与发展。</p>

<p>叶葆定先生早年毕业于美国麻省理工学院（MIT），其夫人李惠荃则为岭南大学校友。二人携手七十余载，深厚的岭南情缘使他晚年倾力支持岭南教育。从1998年至2006年，叶葆定共为岭南国际MBA项目捐资<strong>620多万美元</strong>，累计捐款<strong>5600多万港元</strong>，并于辞世前依遗嘱再赠岭南学院<strong>170万美元</strong>。</p>

<p>叶葆定先生的资助涵盖了岭南MBA大楼、岭南教授住宅大楼、岭南国际MBA与MIT合作办学等项目，为岭南商学教育的快速发展奠定了坚实基础。2000年落成的叶葆定堂，不仅是一座现代化教学大楼，更是岭南校友精神与教育报国情怀的象征。</p>

<p>叶葆定一生简朴，热心教育，被誉为<strong>“岭南姑爷”</strong>，他将一生的财富与心血倾注于教育事业。叶葆定堂的存在，不仅纪念了这位百岁老人的赤子之心，更成为岭南学院学子不断追求卓越、放眼世界的精神地标。</p>`
    },
    {
      id: 71,
      name: '中山大学北门牌坊',
      position: '-',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_071_north_gate_archway.jpg',
      description: `<p><strong>中山大学牌坊</strong>，简称“中大牌坊”，位于广州校区南校园北门，珠江南岸广场，是广州人心目中最具代表性的中大地标。整座牌坊古色古香，庄严大气，用钢筋三合土筑成，外饰以花岗石砌成，前后石柱分两行，共分五门，高 <strong>10.98 米</strong>，宽 <strong>25.315 米</strong>。门额正中镌刻“国立中山大学”六个大字，成为中大百年历史的视觉象征。</p>

<p>最初的中大牌坊建于<strong>1935 年</strong>，位于广州市五山路，作为当时中大校区正门。门内还刻有“格致、诚正、修齐、治平”等校训寓意。1952 年院系调整后，中大迁至康乐园，五山校区划归他校，牌坊的作用逐渐消失。</p>

<p>如今我们所见的中大牌坊建于<strong>2001 年</strong>，是参照五山路旧牌坊复制而成，屹立于南校园北门，与珠江对岸的天际线相呼应。它不仅是校园的重要门户，更承载着中大人对校史的深情记忆。</p>`
    },
    {
      id: 72,
      name: '伍沾德堂',
      position: '南校园586号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_072_wu_zhande_hall.jpg',
      description: `<p><strong>伍沾德堂</strong>位于中山大学广州校区南校园西南部，是一座承载着校友深情与教育使命的标志性建筑。该堂由著名爱国侨领、慈善家<strong>伍沾德博士</strong>慷慨捐资兴建，以其名字命名，寓意“以己之力，泽被母校”。</p>

<p>伍沾德（1913—2010），祖籍广东台山，旅居马来西亚，是著名的企业家、社会活动家和慈善家，曾任马来西亚国会上议员、世界台山同乡会总会会长。伍博士一生心系桑梓和教育，曾多次向中山大学捐赠巨款，用于学校发展与人才培养，特别是在岭南学院 MBA 教育与国际合作方面贡献卓著。</p>

<p><strong>伍沾德堂</strong> 建筑整体采用岭南红砖绿瓦风格，融入现代功能布局，内设多间阶梯教室与学术报告厅，是岭南学院乃至全校举办国际学术交流、工商管理课程教学和校友活动的重要场所。堂内多媒体设施完备，空间设计兼具学术氛围与开放格局，象征着岭南学院“本土与国际并举”的教育理念。</p>

<p>这座建筑不仅是校园的一处地标，也是中大与海外华人情谊的见证。伍博士曾说：<strong>“母校是我的根，能为中大尽力是我最大的心愿。”</strong>伍沾德堂因此成为中山大学校友反哺母校、推动教育兴盛的重要象征。</p>`
    },
    {
      id: 73,
      name: '丰盛堂',
      position: '南校园583号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_073_fengsheng_hall.jpg',
      description: `<p><strong>丰盛堂</strong>是中山大学广州校区南校园的一幢现代化实验大楼，由化学学院教授<strong>刘汉钦</strong>与其夫人<strong>康北笙</strong>于<strong>1995年</strong>集资650万元倡建而成，象征着学术伉俪的爱国情怀与无私奉献。</p>

<p>丰盛堂的建设不仅改善了化学院的科研条件，也凝聚了两位教授的教育初心。他们同时设立了<strong>“丰盛奖学金”</strong>，<strong>每人5000元</strong>，用以鼓励学生科研，并出资建立面向全校学生的紧急援助基金，帮助遭遇突发困难的学子渡过难关。</p>

<p><strong>伉俪故事：</strong></p>
<ul>
  <li><strong>异国邂逅：</strong>1963年，康北笙赴美芝加哥大学留学，与刘汉钦在密歇根湖畔初次相遇，相知相守，并在纽约结婚。</li>
  <li><strong>心怀祖国：</strong>博士毕业后，他们在德国、意大利继续科研，但始终怀着报国之心，最终毅然回到祖国。</li>
  <li><strong>科研合作：</strong>康北笙负责合成，刘汉钦负责表征，夫妻二人并肩带领研究生团队，在结构化学领域取得丰硕成果。</li>
</ul>

<p><strong>教育贡献：</strong> 康北笙教授不仅承担本科生专业英语课程，还倾心培养研究生，数百名学生如今已成为高校与研究所的骨干。她先后承担国家与省市科研课题30余项，发表论文300余篇，获多项自然科学奖。刘汉钦教授则以校友身份回馈母校，推动化学院科研与教学条件的改善。</p>`
    },
    {
      id: 74,
      name: '中山大学西北门',
      position: '-',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_074_northwest_gate.jpg',
      description: `<p><strong>中山大学西北门</strong>位于广州校区南校园的西北角，毗邻生活区与教学区的交界地带，是师生日常出入的重要通道之一。</p>

<p>西北门不仅连接着校园内部主干道与周边居民区，也通往生活配套设施和邻近商区，因而成为学生日常购物、就餐及出行的常用路径。作为校园的门户之一，西北门既承担了交通功能，也见证了校园生活的便利与开放。</p>`
    },
    {
      id: 75,
      name: '伍舜德图书馆',
      position: '南校园576号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_075_wu_shunde_library.jpg',
      description: `<p><strong>伍舜德图书馆</strong>位于中山大学广州校区南校园哲生堂北，1996年9月正式开放，是学校重要的学科分馆之一。</p>

<p>该馆由岭南大学校友、香港美心食品集团创始人<strong>伍舜德（1912—2003）</strong>及美国岭南基金会捐资兴建，1994年投入500万港元启动建设，建筑面积约<strong>5000平方米</strong>，设有<strong>625个阅览座位</strong>。2005年并入中山大学图书馆系统后，定名为<strong>经济与管理学科分馆</strong>，同时保留原名，并由中山大学图书馆与岭南（大学）学院共建。</p>

<p><strong>馆藏与资源：</strong></p>
<ul>
  <li>藏书总量约<strong>9万余册</strong>；</li>
  <li><strong>1036种</strong>专业工具书（含各类经济统计年鉴与专业资料）；</li>
  <li>美国麻省理工学院赠送的<strong>3000册英文原版图书</strong>；</li>
  <li>中外文期刊<strong>627种</strong>（其中外文期刊58种），核心期刊完整率达<strong>92%以上</strong>；</li>
  <li>拥有<strong>10余个专业数据库</strong>，通过校园网开放查询。</li>
</ul>

<p><strong>发展与特色：</strong></p>
<ul>
  <li>1995年起确立建设<strong>中小型电子图书馆</strong>的目标；</li>
  <li>1997年铺设光纤并建成80台电脑的<strong>网络电子室</strong>；</li>
  <li>2000年实现<strong>图书借还自动化</strong>，在华南地区同类馆中处于领先水平；</li>
  <li>按学科划分自习空间，实行分层管理，配备博士生、硕士生与本科拔尖班专属学习区域。</li>
</ul>`
    },
    {
      id: 76,
      name: '岭南堂',
      position: '南校园577号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_076_lingnan_hall.jpg',
      description: `<p><strong>岭南堂</strong>位于中山大学广州校区南校园，是一幢三层建筑，由岭南大学校友捐建，建成于<strong>1994年</strong>，由岭南建筑大师<strong>佘畯南</strong>与<strong>莫伯治</strong>设计。</p>

<p><strong>规划争议：</strong> 在中山大学校园规划调整中，岭南堂是否拆除曾引发热议。校方原计划为打通校园中轴线而拆除岭南堂，但该方案引起社会与校友广泛关注。在476条公示意见中，有<strong>122条明确反对</strong>岭南堂拆除。</p>

<p><strong>不同声音：</strong></p>
<ul>
  <li>部分委员认为，岭南堂作为大师级建筑作品，体量不大，也不张扬，且已经成为现实存在，应予以保留。</li>
  <li>也有学者指出，岭南堂的选址本身存在问题，破坏了岭南大学的历史规划与中轴线的整体风貌，因此支持“纠偏”。</li>
</ul>

<p><strong>结果：</strong> 最终，广州市规委会决定<strong>岭南堂不予拆除</strong>。时任市长<strong>陈建华</strong>表态，岭南堂与科技文化交流中心将一并保留，“已经成为现实，拆确实不合适，留着它可以作为反面教材。”</p>`
    },
    {
      id: 77,
      name: '马应彪招待室',
      position: '南校园388号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_077_ma_yingbiao_reception_room.jpg',
      description: `<p><strong>马应彪招待所</strong>位于中山大学广州校区南校园东北区388号，建成于<strong>民国十一年（1922年）</strong>。该建筑由岭南大学校董、著名实业家<strong>马应彪</strong>先生全额出资兴建，并购置室内家具及陈设，因此以其名字命名。会客厅曾悬挂马应彪夫妇及子女的合影，以示纪念。</p>

<p><strong>建筑特色与功能：</strong></p>
<ul>
  <li>招待所坐西朝东，当时被誉为岭南校园内“最新最漂亮的招待室”。</li>
  <li>首层除办公室外，设有可容纳五六十人的会客厅，用于集会与聚餐。</li>
  <li>二层设有四间客房，供接待宾客住宿，西侧另有天台。</li>
  <li>阁楼与地下室作为管理人员的住所，厨房亦设于地下室。</li>
  <li>招待所门额由著名金石学家<strong>商承祚</strong>教授题写篆书“马应彪招待所”。</li>
</ul>

<p><strong>历史沿革：</strong></p>
<ul>
  <li>民国三十七年（1948年前后），该楼曾改为岭南大学单身教员宿舍。</li>
  <li>南侧外墙曾嵌有一颗炮弹——这是1922年粤军陈炯明部叛乱发动兵变时的流弹，击中墙体后未爆炸。平叛后，岭南大学将炮弹嵌入墙上，以昭示叛军罪行。</li>
  <li>遗憾的是，这枚具有历史印记的炮弹于<strong>2007年意外失踪</strong>，如今外墙仅留弹孔遗迹。</li>
</ul>`
    },
    {
      id: 78,
      name: '哲生堂',
      position: '南校园571号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_078_zhesheng_hall.jpg',
      description: `<p><strong>哲生堂</strong>位于中山大学广州校区南校园西北区571号，原12号建筑。该楼由<strong>国民政府铁道部</strong>拨款建设，美国建筑师<strong>墨菲（Henry Killam Murphy）</strong>于1930年设计，<strong>1929年12月奠基，1931年8月落成</strong>。为感谢国民政府铁道部长<strong>孙科</strong>的鼎力相助，以其字“哲生”命名。</p>

<p><strong>建筑与功能：</strong></p>
<ul>
  <li>最初作为岭南大学工学院大楼使用，是岭大校园中重要的理工学科教学中心。</li>
  <li>1948年前后，顶楼曾设有自然博物馆，收藏与展示动植物标本。</li>
  <li>现堂匾“哲生堂”由著名金石学家<strong>商承祚</strong>题写。</li>
</ul>

<p><strong>历史背景：</strong></p>
<ul>
  <li>1927年岭南大学收归国人自办，<strong>孙科</strong>出任第一届校董会主席。</li>
  <li>1929年，国民政府铁道部为培养铁路与公路专门技术人才，委托岭南大学筹办工科学院，并与岭大订立十则条约，明确学院的名称、性质、地址与经费。</li>
  <li>哲生堂作为工学院大楼的兴建，正是这一合作的重要成果。</li>
</ul>

<p><strong>人物背景：</strong></p>
<p><strong>孙科（1891–1973）</strong>，字哲生，是<strong>孙中山先生的独子</strong>。他早年在檀香山受教育，归国后投身政治事业，三度担任广州市长，对市政建设作出重要贡献。此后历任国民政府委员、铁道部长、考试院长、立法院长、行政院长及国民政府副主席。</p>
<p>孙科曾以蒋介石特使身份赴莫斯科，与苏联谈判并签署《中苏互不侵犯条约》和《中苏商务条约》，在中外外交史上具有重要地位。</p>`
    },
    {
      id: 79,
      name: '陆佑堂',
      position: '南校园565号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_079_lu_you_hall.jpg',
      description: `<p><strong>陆祐堂</strong>位于中山大学广州校区南校园西北区565号，原33号建筑。由美国建筑师<strong>墨菲（Henry Killam Murphy）</strong>设计，<strong>1930年</strong>开工，<strong>1931年</strong>落成。</p>

<p><strong>建筑缘起：</strong> 本堂由<strong>黄容康、黄容章兄弟</strong>捐助大部分建筑经费，其余由同学筹措基金会筹集。原拟以其父黄汉秋命名为“汉秋堂”（Han Chiu Hall），后改以其养父之名，定为“陆祐堂”。</p>

<p><strong>功能沿革：</strong></p>
<ul>
  <li>初建时为岭南大学第三寄宿舍，与爪哇堂（第一寄宿舍）、荣光堂（第二寄宿舍）并称大学三大寄宿舍。</li>
  <li>堂匾“陆祐堂”最初为<strong>商承祚</strong>题写，现存堂匾亦为其1981年再题。</li>
</ul>

<p><strong>建筑特色：</strong></p>
<ul>
  <li>整体为四层建筑，另设阁楼，外观仿宫殿式，上盖<strong>绿琉璃瓦</strong>，屋脊以<strong>蓝琉璃瓦</strong>装饰。</li>
  <li>檐角悬挂蓝釉瓦钟，原有四只，今仅存东南角一只，且已残破。</li>
  <li>装饰丰富，檐角衬以雄狮，四面垂檐点缀<strong>人像及鸟兽陶塑</strong>。</li>
  <li>二层东西两侧设阳台，三层为通绕全堂的骑楼，配以三合土白栏杆。</li>
  <li>立面色彩分明：首、二层为<strong>淡红色</strong>，三、四层为<strong>淡黄色</strong>，墙柱<strong>朱红</strong>，檐柱、栏杆均饰以彩绘。</li>
</ul>`
    },
    {
      id: 80,
      name: '爪哇堂',
      position: '南校园555号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_080_java_hall.jpg',
      description: `<p><strong>爪哇堂</strong>位于中山大学广州校区南校园西北区555号，原34号建筑。由上海布道团建筑师事务所设计师<strong>埃德蒙兹（Jas. R. Edmunds Jr.）</strong>于1918年设计，<strong>1920年</strong>动工。</p>

<p><strong>建筑缘起：</strong> 1919年，岭南大学副监督<strong>钟荣光</strong>先生赴印度尼西亚爪哇各地向华侨募捐建造宿舍经费，得到总领事欧阳祺、中华商会会长<strong>丘燮亭</strong>的大力支持，以及郭天如、陈穰、陈三九等人的协助。其后，泗水、三宝垄、巴城、海防、万隆、勃良安等地十余位华侨和商会纷纷捐款。为铭记爪哇华侨对岭南大学教育事业的热诚襄助，校方将该楼命名为“爪哇堂”。</p>

<p><strong>功能沿革：</strong></p>
<ul>
  <li>爪哇堂为岭南大学<strong>第一寄宿舍</strong>，与<strong>荣光堂</strong>（第二寄宿舍）、<strong>陆祐堂</strong>（第三寄宿舍）并称大学三大寄宿舍。</li>
  <li>现堂匾“爪哇堂”为著名书法家<strong>容庚</strong>先生所题。</li>
</ul>`
    },
    {
      id: 81,
      name: '博物馆',
      position: '南校园543号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_081_museum.jpg',
      description: `<p><strong>中山大学博物馆</strong>位于广州南校园中轴线西侧，与东侧图书馆遥相呼应，形成中轴对称。作为大学文化积淀的集中展现，它不仅是学校历史与文化的实物表征，更是中大一流大学建设的重要标志。</p>

<p><strong>历史沿革：</strong> 中山大学自建校伊始即重视实践教育和实物教学。20世纪初，理科学院、农科学院、医学院以及语言历史学研究所均设立了各类标本室与陈列室。1953年，在原岭南大学文物馆和国立中山大学文科研究所陈列室的基础上，合并成立<strong>中山大学文物馆</strong>，并组建文物保管委员会，设立中山先生纪念室、鲁迅先生纪念室和古物陈列室。此后，生物系和地理系标本室进一步扩展，藏品数量与展陈手段不断提升。</p>

<p><strong>博物馆体系发展：</strong> 经过多年建设，中山大学先后建成了<strong>生物博物馆、人类学博物馆、地质矿物博物馆、医学博物馆</strong>四座专业博物馆，以及若干纪念室与陈列室。中山大学图书馆、档案馆也承担了部分藏品征集与展示的功能。2018年，学校正式成立<strong>中山大学博物馆（校史馆）机构</strong>，并在南校园筹建新馆，目标是打造集教学、展示、研究、收藏为一体的高水平综合性博物馆。</p>

<p><strong>南校园博物馆建筑：</strong></p>
<ul>
  <li>占地面积约<strong>1.1万平方米</strong>，总建筑面积约<strong>3.3万平方米</strong>；</li>
  <li>建筑布局为地上3层、地下2层，主要功能以服务教学与人才培养为核心，深化教育改革，拓展文化育人内涵；</li>
  <li>外观设计延续康乐园早期建筑群风格，采用<strong>红砖绿瓦</strong>与中大传统窗、墙、柱、顶等建筑元素；</li>
  <li>融入岭南建筑特色，利用拱券结构营造室内外过渡空间，蕴含浓厚的地方文化意蕴。</li>
</ul>`
    },
    {
      id: 82,
      name: '八角亭',
      position: '博物馆（543）前',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_082_octagonal_pavilion.jpg',
      description: `<p><strong>八角亭</strong>，原55号建筑，现位于中山大学广州校区南校园西北区542号，由上海布道团建筑师事务所（Mission Architects Bureau, Shanghai）设计师<strong>埃德蒙兹（Jas. R. Edmunds Jr.）</strong>于1919年设计并建成。</p>

<p><strong>建筑特色：</strong> 八角亭为两层建筑，每层呈四角造型，亭子底座为八边形。原设计为蓝瓦脊、绿瓦面，二层设绿瓦花窗。如今屋顶改为宝蓝色琉璃瓦，亭顶饰有<strong>水果篮造型陶塑</strong>，首层屋檐四角下各置一绿色龙头，兼具岭南建筑的装饰趣味与西式亭阁的匠心。</p>

<p><strong>功能沿革：</strong></p>
<ul>
  <li>初建时为<strong>艺徒果店</strong>，年盈利约750元，用作<strong>岭南大学学生青年会</strong>开办艺徒学校的经费；</li>
  <li>1934年3月，因售卖熟食影响环境卫生，被学校收回，改办<strong>消费合作社</strong>，主营茶饼、鲜果、汽水、雪糕等；</li>
  <li>2003年前，曾作为中山大学<strong>物理科学与工程技术学院电介质实验室</strong>使用。</li>
</ul>`
    },
    {
      id: 83,
      name: '乙丑进士牌坊',
      position: '八角亭前',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_083_yichou_jinshi_archway.jpg',
      description: `<p><strong>乙丑进士牌坊（Memorial Archway for the 1625 Imperial Scholars）</strong>建于明崇祯八年（1635年），为表彰天启年间广东籍七位进士——<strong>梁士济、李斯觉、罗亦儒、吴元翰、岑之豹、尹明翼、高魁</strong>而建，最初矗立于广州四牌楼。</p>

<p><strong>迁移与保护：</strong> 20世纪40年代，广州市政府因拓宽道路，拟迁移原位于马路上的五座牌坊。岭南大学将此牌坊迎至校园，最初立于<strong>格兰堂西侧</strong>。1999年，该牌坊得到修复，得以延续其历史文脉。</p>

<p><strong>建筑特色：</strong> 现存牌坊为<strong>砂岩砌筑</strong>，三间四柱五楼石结构。各楼下均设有石制斗拱承托出檐，整体造型古朴厚重。石额正面镌刻“乙丑进士”四字，庄严肃穆。现存构件包括柱、梁坊、额坊、抱鼓石等，用材硕大，工艺精湛。</p>

<p><strong>纹饰与铭刻：</strong></p>
<ul>
  <li>额坊残件上仍可见梁士济、李斯觉等七位进士的名字；</li>
  <li>抱鼓石及梁额处饰有<strong>梅雀、万字纹、棱形图案</strong>等传统纹饰，线条清晰，寓意吉祥。</li>
</ul>`
    },
    {
      id: 84,
      name: '惺亭',
      position: '中轴线上乙丑进士牌坊旁',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_084_xing_pavilion.jpg',
      description: `<p><strong>惺亭</strong>，又称钟亭、烈士钟亭，坐落于中山大学康乐园内。该亭由岭南大学“惺社”毕业生为报本思源、纪念三位校友烈士——<strong>史坚如</strong>、<strong>区励周</strong>、<strong>许耀章</strong>而筹资兴建，由美国建筑师<strong>墨菲</strong>（Henry Killam Murphy）于1928年设计并落成。亭额“惺亭”二字为古文字学家<strong>商承祚</strong>教授题写，使其更添文化价值。</p>

<p><strong>纪念人物：</strong></p>
<ul>
  <li><strong>史坚如</strong>（1896–1928），广东番禺人，民主革命家，中国同盟会成员。曾参与辛亥革命与广东独立运动，后投身国民革命，支持孙中山<strong>“三大政策”</strong>。1928年因坚持革命立场被捕遇害，年仅32岁。</li>
  <li><strong>区励周</strong>（1896–1973），广东南海人，著名<strong>教育家</strong>、翻译家。曾任中山大学教授、文学院院长、校长，推动学术自由与教育改革，抗战时期任国民参政会参政员，积极投身抗日救国。</li>
  <li><strong>许耀章</strong>，广东南海人，民主革命家，早年加入同盟会，参与辛亥革命和北伐，历任要职。曾任广州市市长，推动市政建设与教育改革，为广州现代化与国民素质提升作出贡献。</li>
</ul>

<p><strong>历史与意义：</strong> 惺亭不仅是岭南学子追思革命先烈的纪念地，更象征着中山大学<strong>“读书不忘救国、救国不忘读书”</strong>的精神传承。亭体小巧端庄，寓意庄重肃穆，既承载了三位烈士的爱国情怀，也激励后人铭记历史、勇担使命。</p>
<p><strong>史料补充｜广大学生会传单</strong></p>
<p><em>刊载：</em>《国立广东大学周刊》1925年11月16日第31号第四版。<br>
<em>背景：</em>为“沙基死难众烈士”国葬日所发的学生会呼吁。</p>
<blockquote>
  <p>
    今天是沙基死难众烈士的国葬日了！在今天三个月以前！六月廿三！我们的烈士因为反抗帝国主义者以牺牲了他们无限的头颅和热血！现在又国葬他们了，提越来，多么痛心呢！在他们一一众烈士一一可算是尽了他们责任，瞑目地下矣!可是我们后死者，应该如何承继他们的精神为国努力一一替他们报仇？所以我们无论农商学及其他各界，应永久秉其奋斗牺牲的精神，去继续他们未竟的工作：
  </p>
  <ul>
    <li>打倒帝国主义！</li>
    <li>废除不平等条约！</li>
    <li>求中国之自由平等！</li>
  </ul>
</blockquote>
<p style="text-align:right;">—— 国立广东大学学生会（1925年11月16日）</p>

`
    },
    {
      id: 85,
      name: '孙中山先生铜像',
      position: '中轴线',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_085_sun_yat_sen_bronze_statue.jpg',
      description: `<p><strong>孙中山先生铜像（Statue of Dr. Sun Yat-sen）</strong>矗立于中山大学广州校区南校园的中轴线上，端庄肃立，面向中央大草坪，成为康乐园最具象征性的标志之一。该雕像由日本友人<strong>梅屋庄吉</strong>捐赠，是由日本雕刻家<strong>牧田哉</strong>设计、<strong>筱原雕金店</strong>铸造。铜像与<strong>1931年1月</strong>由中国军舰<strong>靖安号</strong>护送到广州，原安置于石牌校址，<strong>1956年11月12日</strong>被迎置于<strong>康乐园</strong>。后其他校区雕塑都参照其复制而来</p>

<p>铜像造型简洁而庄严，孙中山先生身着长袍马褂，双手下垂，神情坚毅，目光远眺。特别值得一提的是，<strong>铜像面向北方，寓意着他以广州为革命策源地，誓师北伐、振兴中华</strong>，仿佛仍在思索着民族复兴与教育强国的宏图。铜像底座镌刻着他生前的题言与生平事迹，使人一望便能感受到那份跨越时空的力量。</p>

<p><strong>历史印记：</strong></p>
<ul>
  <li>1924年，孙中山先生亲手创办<strong>国立广东大学</strong>，并兼任首任校长，后为纪念其伟业而更名为<strong>“国立中山大学”</strong>。</li>
  <li>他曾在岭南大学、国立中山大学多次发表演讲，勉励青年<strong>“立志要做大事，不可要做大官”</strong>。</li>
  <li>孙中山先生不仅是中山大学的缔造者，更是推动中国近代教育现代化的重要先驱。</li>
</ul>

<p><strong>精神意义：</strong> 这尊铜像不仅是对孙中山先生伟大革命精神的纪念，更是中山大学<strong>“博学、审问、慎思、明辨、笃行”</strong>校训的象征。它提醒着一代又一代中大学子，承续先驱遗志，将个人理想与民族复兴紧密相连，以知识报国，以行动担当。</p>
<p><strong>改名事宜：</strong></p>
<p><strong>一、1925年3月24日《广州民国日报》：改广大为中山大学之提议</strong></p>
<blockquote>
昨有国民党员黄行致函中央党部云，中央执行委员会诸君并转汪精卫、邹海滨先生暨诸同志鉴：黯电传来，天下太息，惟先生虽死，主义犹存，吾侪正宜毅其余勇，努力三民，竟先生未竟之志，励后死之竞也。顷阅报载北京同志改中央公园为中山公园，南京为中山城等语。景仰元老，人有同情。而吾粤为革命策源地，又为先生桑梓所在，更不可以无纪念，似宜将广东大学改为中山大学。查以党建国，为先生之特见，以党建校，宣传之要图，是否有当，伏候公决。中国国民党员黄行仰。
</blockquote>

<p><strong>二、1925年10月9日 校方呈文：邹鲁关于请改职校成立日期为国立中山大学成立日期的呈及批</strong></p>
<blockquote>
呈为呈请事：窃维职校为先大元帅所手创，亦为先大元帅所演讲三民主义之地，拟改为国立中山大学，以留纪念。业经提出第二十八次校务会议议决，并拟于本年十一月十一日（系职校成立一周年纪念之日）为改国立中山大学之期，并经函致中央执行委员会第一百零八次会议议决通过，函复到校。兹拟请将职校改为国立中山大学成立日期，理合备文，呈报钧府察核备案，仍候指令核遵。谨呈<br>
国立广东大学校长邹鲁<br>
中华民国十四年十月九日
</blockquote>

<p><strong>三、1926年4月12日《广州民国日报》第3版：中央党部推定中山大学筹备委员</strong></p>
<blockquote>
国立广东大学校，经政府决定改为中山大学，各节已见前报。该校校长诸民道，昨函请中央党部推举代表一人为中山大学筹备委员会委员，经中央党部第十八次常务会议，推定中央青年部部长甘乃光先生担任云。
</blockquote>
`
    },
    {
      id: 86,
      name: '史达理堂',
      position: '南校园536号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_086_shidali_hall.jpg',
      description: `<p><strong>史达理堂</strong>，又称陆达理堂、科学馆、理学馆，原52号建筑，现西北区536号。因与东院的马丁堂相对，亦被称为“西院”。</p>

<p>该建筑由<strong>美国史达理夫人（Mrs. Willard D. Straight）</strong>和<strong>洛克菲勒基金会（Rockefeller Foundation）</strong>于1925年共同捐资兴建，由建筑师<strong>埃德蒙兹（Jas. R. Edmunds Jr.）</strong>和<strong>霍尔（Howard G. Hall）</strong>设计，1926年动工，1928年10月正式落成。</p>

<p><strong>学术功能：</strong> 史达理堂是岭南大学理学院大楼，也是岭南大学开办以来第一座真正意义上的理科实验室大楼。其内部空间分布如下：</p>
<ul>
  <li>一层 —— 物理学系</li>
  <li>二层 —— 化学系</li>
  <li>三层 —— 生物学系</li>
  <li>四层 —— 植物标本室</li>
  <li>地下室 —— 储藏室（抗日战争时期曾改作临时课室）</li>
</ul>

<p><strong>历史与价值：</strong> 作为岭南大学理科教育与科研的核心基地，史达理堂不仅见证了岭南大学在自然科学领域的拓展，也成为当时南中国科学教育的重要象征。它体现了中西合璧的建筑风格与岭南大学“实事求是、兼容并包”的教育精神。</p>`
    },
    {
      id: 87,
      name: '激光光学大楼',
      position: '南校园558号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_087_long_kanghou_sculpture.jpg',
      description: `<p><strong>光电材料与技术国家重点实验室</strong>依托中山大学建设，由国家科技部批准设立。其前身为著名光谱物理学家、教育家<strong>高兆兰</strong>先生于1984年倡建的超快速激光光谱学国家重点实验室，是全国首批建设的10个国家重点实验室之一。</p>

<p>2001年，在<strong>许宁生院士</strong>的领导下，原“超快速激光光谱学国家重点实验室”与“广东省显示材料与技术重点实验室”合并重组，更名为“光电材料与技术国家重点实验室”。实验室深度融合<strong>材料科学与工程、电子科学与技术、光学工程、物理、化学</strong>等相关学科，从材料与器件层面入手，以<strong>无机、低维、纳米光电材料</strong>为重点，构建了完整的研究链条。</p>

<p><strong>科研条件：</strong> 实验室现有4栋科研实验场地，总面积<strong>24710平方米</strong>。建有“光电材料合成与制备”、“光电材料分析与表征”、“光电微纳结构与集成器件研制”和“光电器件与系统表征测试”四大科研平台，涵盖<strong>12个子平台</strong>，总设备价值超过<strong>4.1亿元</strong>。这些平台为光电材料与器件的制备、表征、加工、封装与应用转化提供了系统保障。</p>

<hr/>

<p><strong>激光光学大楼（Laser Optics Building）</strong>位于中山大学广州校区南校园<strong>558栋</strong>，是学校在光学与激光技术领域开展科研与教学的重要阵地。</p>

<p>大楼聚焦<strong>激光原理、光学工程、光电子技术</strong>等前沿方向，配备了先进的激光实验系统、光学检测设备和超净实验室，形成了从基础研究到应用开发的完善科研环境。</p>
`
    },
    {
      id: 88,
      name: '十友堂',
      position: '南校园537号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_088_shiyou_hall.jpg',
      description: `<p><strong>十友堂</strong>位于中山大学西北区537号。该堂由岭南大学<strong>10位校友各出1万元</strong>，并联合数十华侨和商会共同捐建，因而得名“十友堂”。建筑由<strong>埃德蒙兹（Jas. R. Edmunds Jr.）</strong>设计，于<strong>1919年</strong>设计，<strong>1929年12月</strong>落成，正值岭南大学建校25周年。</p>

<p><strong>建筑形制：</strong> 十友堂坐南朝北，为三层建筑，设有地下室与阁楼。楼前两侧原有大理石灯座，镌刻“广州市万国工程公司建筑”中英文字样，后已拆去。现堂匾“十友堂”为<strong>容庚教授</strong>题写。文革期间部分楼顶与房间被焚毁，1971年重修。</p>

<p><strong>历史用途：</strong></p>
<ul>
  <li>最初为岭南大学<strong>农学院大楼</strong>，内设课堂、实验室、陈列室及菜蔬门市部；</li>
  <li><strong>1931年</strong>，原在马丁堂的博物馆迁至十友堂首层大堂；</li>
  <li>长期作为农学院行政与学务活动的集中地。</li>
</ul>

<p><strong>文化价值：</strong> 十友堂不仅是岭南农学教育发展的见证，也是华侨群体支持中国高等教育的缩影。它汇聚了香港、美国、秘鲁、广州等地校友与华侨的善款，彰显了海外华人心系祖国教育的赤诚。</p>

<p><strong>题匾者容庚：</strong> 容庚（1894–1983），原名容肇庚，字希白，号颂斋，广东东莞人。著名古文字学家、考古学家、书法家，其代表作《金文编》《商周彝器通考》在古文字与青铜器研究领域具有经典地位。容庚一生将大量青铜器、书画、古籍等珍贵文物捐赠国家，以<strong>挽救文物流失</strong>，展现出深厚的爱国情怀与学术精神。</p>`
    },
    {
      id: 89,
      name: '模范村',
      position: '南校园509、510、513-515、517-524号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_089_model_village.jpg',
      description: `<p><strong>模范村建筑群</strong>，又称“西区住宅”，是岭南大学教职员住宅区的典型代表。建筑群于<strong>1915年至1930年</strong>间，以校友捐赠与学校拨款相结合的方式先后建成十余栋村屋，成为康乐园内教师住宅的缩影。</p>

<p><strong>建筑特色：</strong> 文献记载中，模范村每栋建筑成本基本不超过万元，均为<strong>两层洋楼式住宅</strong>：上层为宿所与露台，下层设有客堂、膳室、浴房、厨所与储藏室。屋外留有数丈空地，可辟作花圃与菜畦。规划时设想“十间为一列，屋之距离各数丈”，因其展现了当时理想化的教师住宅模式，故名曰“模范”。</p>

<p><strong>历史沿革：</strong></p>
<ul>
  <li><strong>1915—1930年</strong>：陆续建成十余栋村屋，供中西教员及其家属居住；</li>
  <li><strong>20世纪60年代</strong>：模范村仍是康乐园内教职员住宅区；</li>
  <li>部分建筑曾被划作<strong>工人宿舍</strong>，俗称“工人村”；</li>
  <li>后期又改作科研单位办公用房。</li>
</ul>

<p><strong>现存建筑：</strong> 目前保存有<strong>13栋（509、510、513～515、517～524号）</strong>。其中，524号为<strong>“好屋形住宅”</strong>，因岭南大学校董<strong>马应彪</strong>捐赠部分建设费用，曾被称为“马应彪屋”；513号则曾为岭南大学附属中学主任及港沪等地分校校长<strong>司徒卫</strong>的居所。</p>

<p><strong>修缮与再利用：</strong> 由于建筑老化与结构问题，中山大学自<strong>2007年</strong>起启动模范村整体修缮计划，拟在保留历史风貌的基础上，使其重新焕发活力并发挥新的功能。</p>`
    },
    {
      id: 90,
      name: '法学院',
      position: '南校园505号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_090_law_college.jpg',
      description: `<p><strong>中学第三寄宿舍</strong>，原75号建筑，现位于西北区505号。该建筑由<strong>美国纽约斯道顿建筑师事务所（Stoughton & Stoughton Architects）</strong>于1909年设计，<strong>1912年</strong>落成。</p>

<p><strong>捐赠背景：</strong> 建筑经费由<strong>薛百、黄祝求、阮宏沾、谭文伋、伍勋普、林国祥、黄楚民、黄晓林、谭树彬、陈杰初、钟宇、黎旺、卢仰乔、刘三贤、麦德、周家香、周文郭、张炳禧、张绍芳、黄裔仰、黄达仁、金隆</strong>等22位校友及社会贤达捐赠，并得到<strong>安良总商会</strong>和<strong>纽约耶教联会</strong>的支持。</p>

<p><strong>历史沿革：</strong> 中学第三寄宿舍是岭南大学附属中学（岭南大学前身，或称预科）四栋中学宿舍之一，其余三栋分别位于<strong>西南区493号</strong>、<strong>西北区501号</strong>、<strong>西北区507号</strong>。四栋宿舍自西向东呈雁字形展开，南北各两栋，南楼坐南朝北，北楼坐北朝南，建筑风格皆相似。岭南大学早期尚未设大学生宿舍时，大学生曾临时居住于此，膳堂则设于地下室。</p>

<p><strong>现状与特色：</strong> 该建筑如今为<strong>中山大学法学院</strong>的所在地。院门口立有象征法学精神的<strong>“獬豸”</strong>[xiè zhì]雕塑，象征公正、威严与守护，成为学院标志性文化符号，提醒学子秉承法律人的责任与使命。</p>`
    },
    {
      id: 91,
      name: '永芳堂',
      position: '南校园503号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_091_yongfang_hall.jpg',
      description: `<p><strong>永芳堂</strong>位于中山大学广州校区南校园中轴线上，是校园的重要地标建筑之一。1990年，由著名爱国华侨、南源永芳集团董事长<strong>姚美良</strong>先生捐资一千万元人民币兴建。</p>

<p><strong>改造背景：</strong> 原永芳堂建成已近三十年，因结构老化与功能受限，教学与办公环境较为阴暗狭窄。为延续历史文脉、改善教学条件，同时更好地融入康乐园整体风貌，学校决定对永芳堂进行大规模改造。</p>

<p><strong>新外观：</strong></p>
<ul>
  <li>建筑风格由原来的“外方内圆”转变为<strong>红墙绿瓦拱廊</strong>，与康乐园红砖绿瓦的民国建筑群保持一致；</li>
  <li>东侧原有的大台阶和扇形墙被拆除，取而代之的是宽敞的拱廊大厅，<strong>孙中山先生雕像</strong>静立于大厅中央；</li>
  <li>外立面灰白色瓷砖被替换为仿红砖面砖，屋顶新增绿色陶瓦；</li>
  <li>南侧主入口采用多扇拱门设计，使建筑与中轴线及周边环境更加和谐。</li>
</ul>

<p><strong>新功能与教学环境：</strong></p>
<ul>
  <li>建筑空间经过重新布局，内部不规则区域被打通，南北两侧大堂形成通透的对流空间，整体更为宽敞明亮；</li>
  <li>新增约7米高的落地玻璃，大幅提升了室内采光与通风条件；</li>
  <li>三、四层历史系教学科研用房和教师办公室全面翻新，配置了新的书柜与现代化设备；</li>
  <li>新增学术报告厅，功能布局更加合理，建筑面积比改造前增加近一半。</li>
</ul>`
    },
    {
      id: 92,
      name: '人口研究所',
      position: '南校园501号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_092_people_research_academic.jpg',
      description: `<p><strong>中学第四寄宿舍</strong>位于中山大学广州校区南校园西北区501号，原编号76号建筑，落成于<strong>1916年</strong>。</p>

<p><strong>捐赠背景：</strong> 该楼由<strong>吴有胜、吴胜鹏、周佳、陈占梅、区慎刚、林推迁、林义顺、朱子桥、斐君、简照南、郑发、严孟繁、汤信、游祚胜、张郁才、张耀轩</strong>等16人，以及<strong>南洋烟草公司</strong>共同捐建。其中，第三层为张耀轩先生独资，曾以其名命名。</p>

<p><strong>历史功能：</strong> 中学第四寄宿舍为岭南大学附属中学（岭南大学前身，或称预科）四栋寄宿舍之一，其余三栋为西南区493号、西北区505号、西北区507号。四栋宿舍自西向东呈雁字形展开，南北各两栋，南楼坐南朝北，北楼坐北朝南，建筑风格统一，体现岭南校园早期寄宿制特色。</p>

<p><strong>现状用途：</strong> 如今，该建筑作为<strong>中山大学人口研究所</strong>所在地，延续其在教育与科研领域的功能属性，继续在校园学术体系中发挥作用。</p>`
    },
    {
      id: 93,
      name: '学人书境',
      position: '南校园517号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_093_SYSU_publishinghouse.jpg',
      description: `<p><strong>学人书境</strong>位于中山大学广州校区南校园西北区517号，毗邻学一食堂，处于学院办公区、教学楼和教职工生活区之间的连接带，于<strong>2019年8月31日</strong>正式开业。</p>

<p><strong>空间与设计：</strong> 学人书境坐落于红砖绿瓦的百年红楼内，总营业面积约200平方米。一楼为主要书区，大厅中岛展台展示中山大学历史文化、中大学人著作及中大出版社精品图书，西侧房间陈列文学艺术、人文社科、科学技术与文化教育等书籍，并提供校园特许纪念品。二楼区域延续古色古香的风格，设有立地式书柜与中式红木家具，分布于四个独立房间。</p>

<p><strong>功能与特色：</strong></p>
<ul>
  <li>现有图书3000余种，特别注重党的理论和路线方针政策出版物及提升师生专业素养的优秀书籍；</li>
  <li>通过主题化陈列与营销分类方式，满足不同读者的阅读需求；</li>
  <li>除图书业务外，还提供校园文化纪念品，强化校园品牌文化展示。</li>
</ul>

<p><strong>文化交流平台：</strong> 二楼规划为复合型文化交流空间，未来将开放为学术沙龙、小型会议室与观影室，定期举办文化讲座、学术讨论及党建与思想政治教育活动，促进师生互动与学科交流，打造中大校园的文化新地标。</p>`
    },
    {
      id: 94,
      name: '中山大学人文高等研究院',
      position: '南校园507号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_094_deng_shichang_navy_statue.jpg',
      description: `<p><strong>中学第一寄宿舍</strong>，原73号建筑，现位于西北区507号，是岭南大学第一栋由本国校友捐建的建筑物，落成于<strong>1910年3月</strong>。</p>

<p><strong>历史沿革：</strong> 该楼由美国纽约<strong>斯道顿建筑师事务所（Stoughton & Stoughton Architects）</strong>于1909年设计，捐赠人包括<strong>张安甫、梁震东、卢怡若、阮霭如、谭干臣、卢濂若、潘颂民、徐陈氏、梁嵩生、潘佩如、黄祥华、何礼南、曹咏南、朱松乔、蔡述堂、李直绳、杨丕谷、刘渔舫、刘小卓、蔡伯浩</strong>等20人。该楼为岭南大学附属中学（岭南大学前身，或称预科）四栋中学寄宿舍之一，其余三栋分别为西南区493号、西北区501号、西北区505号。四栋宿舍由西向东呈雁字形展开，南北各两栋，建筑风格皆相似。</p>

<p><strong>保护与价值：</strong> 中学第一寄宿舍是岭南大学校友自筹经费捐建的开端，具有重要的纪念意义。2000年被广州市城市规划局列入<strong>近代、现代优秀建筑群体保护名录</strong></p>

<p><strong>现状用途：</strong> 如今，该建筑作为<strong>中山大学人文高等研究院</strong>的所在地，继续承载着学术与文化传承的使命。</p>
`
    },
    {
      id: 95,
      name: '康乐园餐厅',
      position: '南校园609号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_095_kangle_garden_dining_hall.jpg',
      description: `<p><strong>康乐园餐厅（Kangleyuan Dining Hall）</strong>位于中山大学广州校区南校园，是伴随几代中大师生成长的校园食堂记忆。餐厅建筑朴素典雅，红砖绿瓦的岭南风格与康乐园的整体环境融为一体。作为校园生活的重要组成部分，这里不仅承担着师生的日常饮食，更承载了中大人共同的青春回忆。</p>

<p><strong>历史与功能：</strong> 康乐园餐厅自建成以来，一直是南校园的主要食堂之一。内部设有多个就餐区，菜品种类丰富，从传统广式点心、家常小炒到川湘风味、粤式汤品一应俱全，满足了不同口味需求。每逢开学、新春、毕业季，餐厅还会推出应景菜肴，成为师生们交流与聚会的重要场所。</p>

<p><strong>文化意义：</strong> 对许多中大学子而言，康乐园餐厅不仅仅是食堂，更是友谊的见证与青春的缩影。无数次与同学的并肩排队、饭后长谈、考试前的快餐，构成了校园生活中温馨而深刻的记忆。</p>

<hr/>

<p><strong>博士饼（Doctor’s Pastry）</strong>是中山大学校园饮食文化中的一款特色点心，因在<strong>康乐园餐厅</strong>最为出名而成为<strong>“校园限定”</strong>。博士饼外观朴实，口感香酥绵密，甜而不腻，因价格亲民、寓意美好而深受师生喜爱。</p>

<p><strong>名称由来：</strong> “博士饼”的名字寓意“学有所成”，许多师生在攻读硕博学位期间，都会特意品尝这款点心，以此作为求学道路上的小小仪式感。它不仅是一块糕点，更寄托了中大学子对学业精进与前程似锦的美好祝愿。</p>

<p><strong>文化记忆：</strong> 作为一种校园专属的“味觉符号”，博士饼承载了几代中大师生的共同记忆。许多校友在毕业多年后仍念念不忘，视其为<strong>“味蕾上的中大名片”</strong>。</p>
`
    },
    {
      id: 96,
      name: '园西湖',
      position: '康乐园餐厅后',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_096_yuanxi_lake.jpg',
      description: `<p><strong>园西湖（Yuanxi Lake）</strong>位于中山大学广州校区南校园西部，松涛园宿舍区与西区教学生活区之间，是校园内一片静谧而富有诗意的水域景观。</p>

<p><strong>景观特色：</strong> 湖面开阔，四季水色各具韵味：春日新绿倒映湖中，夏季荷叶田田、花香四溢，秋来芦花摇曳、波光潋滟，冬时则有白鹭掠影与清风相伴。湖畔林木繁茂，步道环绕，既是散步、慢跑的天然路线，也是学生课余休憩与社团活动的热门场所。小亭与小桥点缀湖边，为师生提供了眺望与小憩的绝佳空间。</p>`
    },
    {
      id: 97,
      name: '蒲园食堂',
      position: '南校园722号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_097_puyuan_canteen.jpg',
      description: `<p><strong>蒲园食堂（Pu Garden Dining Hall）</strong>位于中山大学广州校区南校园西南生活区，毗邻学生宿舍群，是中大师生日常就餐的主要场所之一。</p>

<p><strong>环境与格局：</strong> 食堂外观延续红砖绿瓦的岭南校园风格，内部空间宽敞明亮，设有多处分区，有600个餐位。内部装修以实用为主，配备空调与通风系统，整体氛围简洁而温馨。</p>`
    },
    {
      id: 98,
      name: '中山大学西门',
      position: '-',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_098_west_gate.jpg',
      description: `<p><strong>西门（West Gate）</strong>虽名为“西门”，却并非朝西而开，而是朝南敞开大门，成为南校园极具趣味性的入口之一。</p>

<p><strong>地理位置与功能：</strong> 西门位于教职工家属区的必经之路，既是师生进出的通道，也是联系校园与生活区的重要节点。</p>`
    },
    {
      id: 99,
      name: '中山大学小西门',
      position: '-',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_099_small_west_gate.jpg',
      description: `<p><strong>中山大学西北门</strong>位于广州校区南校园的西北侧，毗邻生活区与教学区的交界地带，是师生日常出入的重要通道之一。</p>

<p>小西门外连接着<strong>中大菜市场</strong>。</p>`
    },
    {
      id: 100,
      name: '震寰堂',
      position: '南校园629号',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_100_zhenhuan_hall.jpg',
      description: `<p><strong>震寰堂（Zhenhuan Hall）</strong>原由中山大学管理学院使用，现在为数学学院使用，是学院重要的学术与培训活动场所。</p>

<p><strong>建筑与功能：</strong> 震寰堂作为数学学院的核心大楼之一，常年承载教学、培训、学术会议与社会服务功能。其庄重的建筑风格与学院整体环境相融合，成为学术交流与校企合作的重要平台。</p>`
    },
    {
      id: 101,
      name: '你的见闻',
      position: '-',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/sysu_101_your_observations.jpg',
      description: `<p>
  拍摄了这么多，<br>
  那你是否也有了自己最想记录与分享的风景？<br>
  是西大夜空下闪烁的繁星，<br>
  还是雨中康乐园里静谧的慢步，<br>
  抑或是心中那段独属于你的校园记忆……
</p>
`
    },
    {
      id: 202501,
      name: '琴叶珊瑚',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202501.jpg',
      description: `<p><strong>特性：</strong><br> <strong>常绿灌木</strong>，<strong>四季开花</strong>，<strong>火红色小花密集如星</strong>，<strong>植株含有毒乳汁</strong>，是<strong>华南地区</strong>常见的热带观赏花木，适配<strong>公园丛植、道路点缀</strong>等场景。</p> <p><strong>寓意：</strong><br> 花语蕴含 “<strong>热烈、疯狂、自由</strong>” 与 “<strong>爱慕之心、细腻感情、高贵</strong>”，以<strong>全年不辍的火红花色</strong>，传递<strong>持续的活力与炽热的情感</strong>，是彰显生机的经典观赏植物。</p> <p><strong>观赏提示：</strong><br> 此花多植于<strong>校园招新处、公园路旁</strong>，<strong>簇生的火红小花如星火聚燃</strong>，营造出蓬勃热烈的氛围。风过时，若见花瓣与纸张相映，似能窥见藏于其间的赤诚理想。其<strong>汁液含毒</strong>，观赏时需<strong>保持恰当距离</strong> —— 这份热烈之美，当以<strong>敬畏之心</strong>待之，方不负其长久绽放的赤诚，亦护持那份纯粹的追求。</p>`
    },
    {
      id: 202502,
      name: '杜鹃花',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202502.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>常绿或落叶灌木</strong>，<strong>春深时节漫山绽放</strong>，花色以<strong>殷红为主</strong>，花型似<strong>飞鸟振翅</strong>，<strong>雨后花色更显清艳</strong>，因“<strong>杜鹃啼血</strong>”的传说承载深厚文化意涵，适配<strong>山地景观、庭院造景</strong>。</p>

<p><strong>寓意：</strong><br>
借“<strong>杜鹃啼血</strong>”的传说，象征<strong>坚韧不屈的生命力</strong>与<strong>深沉厚重的情感</strong>，既能在<strong>贫瘠山地成片生长</strong>，亦为文人笔下“<strong>执着热爱</strong>”的具象化表达，艳丽花色中藏着对<strong>希望的热烈期盼</strong>。</p>

<p><strong>观赏提示：</strong><br>
春日<strong>山道旁、书院庭院间</strong>常见其影，<strong>殷红花海如燃焰铺展</strong>，<strong>雨后更显清丽卓绝</strong>。若伴书卷观之，落英翩跹时，似能触碰到那份藏于花色中的<strong>不屈之志</strong>。赏花当<strong>惜其完整，勿折枝、勿践瓣</strong> —— 每一片落红，皆是岁月沉淀的赤诚，静静诉说着关于坚守与热爱的故事，待观者体悟其中深意。</p>`
    },
    {
      id: 202503,
      name: '龙船花',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202503.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>茜草科灌木</strong>，<strong>端午前后盛放</strong>，<strong>花序呈聚伞状如火炬</strong>，<strong>花期绵长</strong>，<strong>枝干挺拔且具微刺</strong>，原产<strong>中国南部</strong>，是热带、亚热带地区绿化造景的常用植物，适合<strong>操场边缘、晨练路径旁种植</strong>。</p>

<p><strong>寓意：</strong><br>
因花期与端午赛龙舟相契，花语为“<strong>争先恐后</strong>”，象征<strong>积极奋进、不负韶光的精神</strong>，常被赋予“<strong>事业向上、健康吉祥</strong>”的美好期许，是传递正能量的观赏花木。</p>

<p><strong>观赏提示：</strong><br>
每逢端午，此花便以<strong>火炬般的花序点亮周遭</strong>，多植于<strong>操场、晨练径旁</strong>，与活力场景相得益彰。观赏时宜远观其整体气象，成片火红如竞渡之舟破浪前行，尽显昂扬向上之势。其<strong>枝干带微刺</strong>，似在警示：奋进之路虽需勇往直前，亦当守持本心，方能在时光洪流中稳步向前，不负韶华。</p>`
    },
    {
      id: 202504,
      name: '榕树',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202504.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>桑科常绿乔木</strong>，树冠参天如伞，<strong>气根垂地似须</strong>，叶密荫浓，<strong>寿命可达千年</strong>，“<strong>榕</strong>”与“<strong>容</strong>”谐音，是<strong>福州等城市的市树</strong>，象征<strong>博大胸襟与坚韧品格</strong>，适配<strong>书院、古建旁种植</strong>，营造古朴厚重氛围。</p>

<p><strong>寓意：</strong><br>
以“<strong>气根垂地、树冠广展</strong>”喻示“<strong>有容乃大</strong>”的胸襟，凭抵御台风、耐受干旱的特性，成为<strong>顽强生命力的代表</strong>；<strong>千年树龄承载历史记忆</strong>，是村落、书院的“<strong>精神地标</strong>”，见证岁月变迁与文化传承。</p>

<p><strong>观赏提示：</strong><br>
书院古建之侧，常可见此树苍劲身影，<strong>气根垂落如岁月织就的丝线</strong>，树冠浓荫似庇护万物的怀抱。抚其气根，仿佛触摸一部沉默的史书，那些藏于年轮中的故事，在叶影婆娑间静静流淌。它见证过无数求索的脚步，亦守护着代代相传的<strong>精神根脉</strong>，观之可感历史的厚重，体悟“<strong>有容乃大</strong>”的深远意境。</p>`
    },
    {
      id: 202505,
      name: '荷花',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202505.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>多年生水生草本</strong>，<strong>叶呈盾圆形可承朝露</strong>，<strong>花姿洁净、香气清远</strong>，“<strong>出淤泥而不染，濯清涟而不妖</strong>”，自古被誉为“<strong>君子之花</strong>”，有“<strong>六月花神</strong>”“<strong>水宫仙子</strong>”等雅号，适配<strong>湖畔、池塘造景</strong>。</p>

<p><strong>寓意：</strong><br>
是<strong>高洁、纯洁的象征</strong>，“<strong>出淤泥不染</strong>”喻示<strong>坚守本心、不随波逐流的品格</strong>；<strong>叶上露珠可映天光</strong>，暗含<strong>澄明远见之意</strong>；且<strong>全身皆宝，兼具实用价值与审美价值</strong>，是古今文人墨客歌咏的<strong>经典意象</strong>。</p>

<p><strong>观赏提示：</strong><br>
此花多植于<strong>湖畔池塘</strong>，<strong>晨露未晞时，圆叶承露、花苞初绽</strong>，一派<strong>清宁雅致之景</strong>。静坐湖畔观之，可从其<strong>洁净姿态</strong>中感悟“<strong>出淤泥而不染</strong>”的君子风骨，从<strong>露珠映天的景致</strong>里体悟澄明心境的可贵。乱世纷扰中，这份宁静足以照见前行大道；太平岁月里，这份高洁亦能唤醒内心的澄澈，赏花之时，亦是与自我本心对话之机。</p>`
    },
    {
      id: 202506,
      name: '大花紫薇',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202506.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>千屈菜科乔木</strong>，<strong>虬枝盘曲具古朴之态</strong>，<strong>夏秋季节满树绽放淡红或紫色花朵</strong>，<strong>花期长达百日</strong>，树皮斑驳如刻，<strong>木材坚硬耐腐</strong>，有“<strong>行道树中的美女</strong>”“<strong>紫霞仙子</strong>”的美誉，适配<strong>古建旁、道路两侧种植</strong>。</p>

<p><strong>寓意：</strong><br>
以“<strong>花期绵长、花色艳丽</strong>”象征<strong>长久的美好与坚韧的生命力</strong>，“<strong>虬枝盘曲却繁花满树</strong>”喻示<strong>历经沧桑仍不改绚烂的品格</strong>；可入药解毒敛疮，暗含<strong>守护、治愈的隐性意涵</strong>，是兼具观赏与实用价值的树种。</p>

<p><strong>观赏提示：</strong><br>
古建飞檐之侧、城市道路两旁，常可见此树风姿。<strong>虬枝盘曲间，淡紫或绯红的花串如霞似雾</strong>，与斑驳树皮相映，尽显岁月沉淀的雅致。逆光观之，花枝与古建轮廓交融，似能窥见那份支撑岁月的<strong>坚韧筋骨</strong>。它见证过建筑的变迁，亦以<strong>长久花期传递守护的力量</strong>，赏花时可感其历经风雨仍绽放的执着，体悟那份藏于柔美中的刚强。</p>`
    },
    {
      id: 202507,
      name: '禾雀花',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202507.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>藤本植物</strong>，每年<strong>三、四月间开放</strong>，<strong>花型酷似禾雀</strong>，初开为<strong>乳白色或淡绿色</strong>，盛开后转为<strong>柠檬黄，继而变为粉红色和橙红色</strong>，<strong>损伤花瓣会流出红色汁液</strong>，常成串挂于藤蔓，有“一藤成景、千鸟栖枝”的景观效果，适配<strong>廊架、雨廊绿化</strong>。</p>

<p><strong>寓意：</strong><br>
因“<strong>万朵同枝、一损俱损</strong>”的生长特性，象征<strong>团结共生、同气连枝的情谊</strong>；“<strong>花形如雀聚</strong>”的模样，喻示<strong>友谊相伴、共御风雨的美好愿景</strong>，是营造温馨共生氛围的优质藤本植物。</p>

<p><strong>观赏提示：</strong><br>
春日雨廊廊架上，此花如万千雀鸟栖枝，串串花朵随藤蔓舒展，花色渐变间尽显生机。<strong>春雨绵绵时，藤蔓摇曳、花色流转</strong>，似在诉说<strong>共生共荣的故事</strong>。观赏时切勿折损花瓣，<strong>那流出的红色汁液仿佛是对“同枝共命”的珍视</strong> —— 每一朵花都是整体的一部分，唯有守护这份完整，方能体悟<strong>团结之美</strong>，感受那份相互支撑、共赴时光的深厚意涵。</p>
`
    },
    {
      id: 202508,
      name: '朱槿',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202508.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>锦葵科常绿灌木</strong>，又名<strong>扶桑</strong>，<strong>全年开花</strong>，<strong>单朵花朝开暮落但整体花期不绝</strong>，花色<strong>鲜红无畏</strong>，原产中国，唐前为“<strong>太阳神话神树</strong>”，唐诗中被赋予多重文化内涵，适配<strong>窗台点缀、庭院种植</strong>。</p>

<p><strong>寓意：</strong><br>
以“<strong>朝开暮落却持续绽放</strong>”象征“<strong>刹那永恒、热烈不息</strong>”，鲜红花色代表<strong>勇敢无畏、敢为天下先的精神</strong>；依托古代“<strong>扶桑为日出神树</strong>”的传说，暗含<strong>希望与新生</strong>的寓意，是传递积极力量的观赏花木。</p>

<p><strong>观赏提示：</strong><br>
窗台畔、食堂外围常植此花，<strong>单朵朝开暮落，却有新花接续绽放</strong>，鲜红花色如燃焰不熄，尽显无畏姿态。<strong>逆光观赏，花瓣脉络清晰可见，似藏着一股勇往直前的锐气</strong>。虽单朵生命短暂，却以持续绽放诠释热烈的真谛，观之可感那份“<strong>敢为天下先</strong>”的勇气，体悟即便生命短暂，亦要绽放精彩的人生态度，这份热烈与执着，足以照亮寻常岁月。</p>`
    },
    {
      id: 202509,
      name: '无忧花',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202509.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>豆科常绿乔木</strong>，<strong>夏季开花</strong>，花呈<strong>橙黄至深红色</strong>，簇生于树干之上，传说<strong>佛祖诞生于无忧花树下</strong>，坐其下可忘却烦忧，是傣族寺庙旁常见的“<strong>吉祥树</strong>”，适配<strong>公园、寺庙周边种植</strong>。</p>

<p><strong>寓意：</strong><br>
借“<strong>佛祖诞生</strong>”的传说，象征<strong>无忧吉祥</strong>，人们相信静坐其下能获得内心安宁、忘却烦恼；花开如<strong>金色火炬</strong>，代表对美好未来的期许，亦承载着“<strong>新生与希望</strong>”的美好愿景，是传递温暖与慰藉的树种。</p>

<p><strong>观赏提示：</strong><br>
公园一隅、寺庙周边常可见此树，<strong>夏季花开时，橙黄至深红的花朵簇生树干，如金色火炬点亮周遭</strong>。静坐树下，风拂枝叶的轻响似在诉说关于“<strong>无忧</strong>”的古老故事，那份宁静与温暖，足以抚慰内心烦忧。它承载着对天下安宁的期盼，见证过无数人对未来的憧憬，赏花时可暂忘俗世纷扰，感受那份对美好未来的向往，亦体悟为守护这份“<strong>无忧</strong>”而付出的努力与坚持。</p>`
    },
    {
      id: 202510,
      name: '白千层',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202510.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>桃金娘科乔木</strong>，树皮呈<strong>灰白色</strong>，厚而松软且呈薄层状剥落，花型如<strong>白色小毛刷</strong>，枝叶含芳香油，有镇静神经之效，原产澳大利亚，中国华南地区多有栽种，适配<strong>道路绿化、宿舍周边种植</strong>。</p>

<p><strong>寓意：</strong><br>
以“<strong>树皮层层剥落</strong>”象征绵长不绝的牵挂与守护，每一层树皮都似一句叮咛，传递温暖安心的情感；枝叶含芳香油可镇静神经，暗含“<strong>默默守护健康与心灵</strong>”的意涵，是兼具实用与情感价值的树种。</p>

<p><strong>观赏提示：</strong><br>
道路两侧、宿舍楼下常见此树，<strong>灰白色树皮层层剥落，花朵如白色小毛刷，散发淡淡清香</strong>。触摸其松软树皮，仿佛能感受到那份层层包裹的温暖与牵挂，如寻常日子里那些不曾停歇的叮嘱。它以独特的姿态守护着过往行人与居者，那淡淡的芳香既能舒缓心绪，亦似在诉说：那些藏于日常的牵挂，便是抵御风雨的力量，观之可感平凡中的温暖，体悟守护的深远意义。</p>`
    },
    {
      id: 202511,
      name: '凤凰木',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202511.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>豆科落叶乔木</strong>，可高达 <strong>20 米</strong>，叶片如飞凰之羽，花朵似丹凤之冠，夏季绽放<strong>鲜红花朵</strong>，木材质地轻韧且富有弹性，花语为“<strong>离别、思念、火热青春</strong>”，是热带地区著名的观赏树种，适配<strong>广场孤植、庭院种植</strong>。</p>

<p><strong>寓意：</strong><br>
以“<strong>花叶形似凤凰</strong>”象征高贵仪态与火热的生命力，花期时红花绿叶相映，是“<strong>青春张扬</strong>”的生动写照；“<strong>木质可雕可塑</strong>”喻示内在品格需经雕琢打磨，方能成为有用之材，承载着对成长与传承的美好期许。</p>

<p><strong>观赏提示：</strong><br>
广场中央、庭院深处常可见此树孤植，枝干挺拔，夏季花开时如丹凤展翅，<strong>鲜红花朵与翠绿叶片相映成趣</strong>，尽显热烈张扬的气质。拾一片落花夹于书卷，花瓣的纹理似在诉说关于成长的故事 —— 外在的绚烂需以内在的坚韧为基，方能在岁月中沉淀出独特的价值。它见证过无数青春的过往，亦以自身生长诠释“<strong>雕琢成器</strong>”的道理，观之可感青春的火热，体悟“<strong>不负时光、砥砺成长</strong>”的深刻内涵。</p>`
    },
    {
      id: 202512,
      name: '木棉',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202512.jpg',
      description: `<p><strong>特性：</strong><br>
<strong>锦葵科落叶大乔木</strong>，可高达 <strong>25 米</strong>，树干挺拔且具圆锥状粗刺，春季先花后叶，满树<strong>红花如火炬</strong>，又名“<strong>英雄树</strong>”，花语与“<strong>英雄、牺牲、成全</strong>”相关，是广州等城市的象征树，适配<strong>纪念广场、城市主干道种植</strong>。</p>

<p><strong>寓意：</strong><br>
因“<strong>树干挺拔、花红似火</strong>”被誉为“英雄树”，象征不屈不挠的英雄气概；“<strong>先花后叶</strong>”的特性喻示牺牲与成全的精神 —— 花开时叶落，以简洁的姿态凸显花的绚烂，如英雄舍己为人的无私品格。</p>

<p><strong>观赏提示：</strong><br>
纪念广场、城市主干道旁多植此树，春季来临，无叶的枝干上绽放满树红花，如火炬燃烧，尽显庄严与热烈。仰望此树，似能感受到那份无声的守护与担当，仿佛有力量在默默支撑，为这片土地带来安宁与希望。它以“<strong>英雄树</strong>”之名，承载着对奉献与牺牲的敬意，观之可感英雄精神的厚重，体悟“<strong>舍己为人、守护家国</strong>”的崇高意境，那份炽热的红色，便是对责任与担当的最好诠释。</p>`
    },
    {
      id: 202513,
      name: '百团燃新火',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202513.jpg',
      description: `<p><strong>事件描述：</strong><br> 了解社团信息，<strong>收藏 3 个感兴趣的社团介绍链接</strong>，并<strong>拍照记录</strong>相关内容。</p>`
    },
    {
      id: 202514,
      name: '逢君杜鹃红',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202514.jpg',
      description: `<p><strong>事件描述：</strong><br>
去南校区寻找正在盛开的<strong>鲜花</strong>，并<strong>拍照记录</strong>花卉景象。</p>`
    },
    {
      id: 202515,
      name: '争流等闲时',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202515.jpg',
      description: `<p><strong>事件描述：</strong><br>
比平时早醒一些，进行<strong>热身运动</strong>，并<strong>拍照记录</strong>运动过程。</p>`
    },
    {
      id: 202516,
      name: '根脉照汗青',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202516.jpg',
      description: `<p><strong>事件描述：</strong><br>
去了解<strong>南校园古树的历史</strong>，并可<strong>拍照记录</strong>你所遇到的古树。</p>`
    },
    {
      id: 202517,
      name: '荷叶鉴清露',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202517.jpg',
      description: `<p><strong>事件描述：</strong><br>
早晨路过<strong>池塘</strong>时，可以观察池塘的<strong>景观</strong>，并<strong>拍照记录</strong>此刻的景色。</p>`
    },
    {
      id: 202518,
      name: '飞檐见自强',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202518.jpg',
      description: `<p><strong>事件描述：</strong><br>
与自己的<strong>朋友</strong>一同参观<strong>校园建筑</strong>，了解<strong>红楼的历史</strong>，并<strong>拍照记录</strong>你中意的红楼。</p>`
    },
    {
      id: 202519,
      name: '同枝系同心',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202519.jpg',
      description: `<p><strong>事件描述：</strong><br>
与朋友在校园中悠闲散步，分享心情与想法，享受轻松交流的时光，并可选择性地拍照记录这份宁静与温暖。</p>`
    },
    {
      id: 202520,
      name: '舌探肝胆灼',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202520.jpg',
      description: `<p><strong>事件描述：</strong><br>
尝试之前未尝试过的新菜系，可选择稍辣的菜肴，体验不同风味与口感，并拍照记录美食的样貌与感受。</p>`
    },
    {
      id: 202521,
      name: '旧语植春晖',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202521.jpg',
      description: `<p><strong>事件描述：</strong><br>
向他人分享你的有趣故事，可选择童年趣事作为素材，交流欢乐经历，并记录下分享的氛围或趣味瞬间。</p>`
    },
    {
      id: 202522,
      name: '千层语叮咛',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202522.jpg',
      description: `<p><strong>事件描述：</strong><br>
与家中长辈沟通交流，可通过电话或视频分享近况，关心彼此生活，并记录下温馨的交流瞬间。</p>`
    },
    {
      id: 202523,
      name: '笺书载凤仪',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202523.jpg',
      description: `<p><strong>事件描述：</strong><br>
给未来的自己写一封信，可在信中记录心情、愿望与目标，也可夹上一片叶子作为书签，留存当下的记忆。</p>`
    },
    {
      id: 202524,
      name: '相望承千古',
      position: '广州校区南校园',
      image: 'https://sysuzngcxy-1322240898.cos.ap-guangzhou.myqcloud.com/Position/202524.jpg',
      description: `<p><strong>事件描述：</strong><br>
路过<strong>孙中山铜像</strong>时驻足观望，可仔细端详雕像的细节与神态，感受历史人物的风采与精神内涵。</p>`
    },
  ]
};
